package test;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import test.domain.dto.BoardWriteDto;
import test.service.BoardService;

@SpringBootTest
class AgileTestApplicationTests {
	@Autowired
	private BoardService service;
	//@Test
	void 저장데트스() {
		IntStream.rangeClosed(1, 10).forEach(i->{
			service.save(BoardWriteDto.builder()
					.subject("제목 테스트 "+i)
					.content("내용 테스트 "+i)
					.writer("작성자"+(i%3+1))
					.build());
		});
		
	}

}
