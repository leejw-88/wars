package test.service;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.BoardWriteDto;

public interface BoardService {


	void getBoardList(Model model);

	void save(BoardWriteDto dto);

	void detail(long no, Model model);

}
