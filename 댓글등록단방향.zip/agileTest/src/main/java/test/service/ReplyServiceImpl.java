package test.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyDto;
import test.domain.dto.ReplyWriteDto;
import test.domain.entity.BoardEntity;
import test.domain.entity.BoardEntityRepository;
import test.domain.entity.Reply;
import test.domain.entity.ReplyRepository;

@Service
public class ReplyServiceImpl implements ReplyService {
	
	//댓글을 저장하기위해 보드 엔티티 러퍼지토리를 가지고 왔다.
	@Autowired
	BoardEntityRepository boardEntityRepository;
	
	//이걸로는 문제가있다.
	//포린키가 없으므로 해당게시글의 댓글이 맞는지 확인 불가.
	@Autowired
	ReplyRepository repository;
	
	//실제로 로직 구현 하는 구간
	@Transactional
	@Override
	public void save(long bno, ReplyWriteDto dto) {
		//댓글을 등록할 목적
		//필요한건 지정된 게시글 번호(bno), 댓글 정보(dto)
		System.out.println("----------------------------------");
		
		Reply rEntity = Reply.builder()
				.reply(dto.getReply()) //
				.writer(dto.getWriter())
				.board(BoardEntity.builder().no(bno).build()) //보드 엔티티를 빌드한다 no값만 설정해준다
				.build();
		
		repository.save(rEntity);
		
		
		/* 게시글 -> 댓글 */
/*		Reply rEntity = dto.toEntity();
		BoardEntity bEntity = boardEntityRepository.findById(bno).orElseThrow();
		//댓글을 가지고 온다..
		List<Reply> re = bEntity.getReplies();
		re.add(rEntity);
		
		boardEntityRepository.save(bEntity);
		
	*/
		}

	@Override
	public ModelAndView getReplies(long bno) {
		ModelAndView mv =new  ModelAndView("/board/reply");
		
		//Sort sort1 = Sort.by(Direction.DESC,"no");
		Sort sort = Sort.by("no").descending();
		List<ReplyDto> result=repository.findAllByBoardNo(bno)
									 .stream()	//스트림을 이용해 콜렉트로 바꾸어도 된다
									 .map(ReplyDto::new)
									 .collect(Collectors.toList());
		
		mv.addObject("replies",result); //foreign key 로 찾는다
		return mv;
	}

}
