package test.service;

import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyWriteDto;

public interface ReplyService {

	void save(long bno, ReplyWriteDto dto);

	ModelAndView getReplies(long bno);

}
