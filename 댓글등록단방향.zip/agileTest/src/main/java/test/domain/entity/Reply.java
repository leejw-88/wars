package test.domain.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Entity
public class Reply {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long rno; //관리 번호 //구분을 위해서 "r"eplay no r을 붙힌다.
	
	@Column(nullable = false) //필수요소, notnull 포함
	private String reply; //내용
	
	@Column(nullable = false)
	private String writer; // 작성자
	
	@CreatedDate
	private LocalDateTime createdDate; // 작성잃
	
	//many에 테이블이 만들진다 FK가 만들어진다
	@ManyToOne
	@JoinColumn(name = "boardNo")
	BoardEntity board;
	
	
}
