package test.domain.entity;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.util.Streamable;

import test.domain.dto.ReplyDto;

public interface ReplyRepository extends JpaRepository<Reply, Long>{
	

	List<Reply> findAllByBoardNo(long bno);
	//메소드에 적용
//	List<Reply> findAllByBoardNoOrderByNoDesc(long bno);

	//파라미터에 적용
	//List<Reply> findAllByBoardNo(long bno, Sort sort);




}
