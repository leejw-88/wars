package test.domain.dto;

import lombok.Data;
import test.domain.entity.Reply;

@Data
public class ReplyWriteDto {
	
	private String reply;
	private String writer;
	
	public Reply toEntity() {
		
		//댓글은 포린키 설정 불가능하다.
		return Reply.builder()
				.reply(reply)
				.writer(writer)
				.build();
	}
	

}
