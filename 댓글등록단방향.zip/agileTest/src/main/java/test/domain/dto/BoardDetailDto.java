package test.domain.dto;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import test.domain.entity.BoardEntity;

@RequiredArgsConstructor
@Data
//게시판 상세정보를 위한 DTO
public class BoardDetailDto {
	
	//게시글 번호, 제목, 작성자, 조회수, 생성날짜를 설정해준다.
	private long no;
	private String subject;
	private String writer;
	private String content;
	private int readCount;
	private LocalDateTime createdDate;
	
	//해당 것들은 엔티티로 만들어준다.
	public BoardDetailDto(BoardEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.writer = entity.getWriter();
		this.content = entity.getContent();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
	}
	

}
