package test.domain.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import test.domain.entity.BoardEntity;
import test.domain.entity.Reply;



@NoArgsConstructor
@Data
public class ReplyDto {
	
	private long no;
	private String reply;
	private String writer;
	private LocalDateTime createdDate;
	
	
	
	public ReplyDto(Reply entity) {
		this.no = entity.getRno();
		this.reply = entity.getReply();
		this.writer = entity.getWriter();
		this.createdDate = entity.getCreatedDate();
	}
	

	

	 

}
