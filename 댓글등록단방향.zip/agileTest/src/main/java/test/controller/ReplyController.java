package test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyWriteDto;
import test.service.ReplyService;
import test.service.ReplyServiceImpl;

@Controller
public class ReplyController {
	
	@Autowired
	private ReplyService service;
	
	
	@ResponseBody //return 이 없으므로... / ajax 사용할때
	@GetMapping("/board/{bno}/reply")
	public ModelAndView reply(@PathVariable long bno) {
		//서비스에서 데이터를 읽어오라고 한다 bno만
		//굳이 파라미터로 안넣고 아래처럼 넣어도 된다
		ModelAndView mv=new ModelAndView();
		
	
		return service.getReplies(bno);
	}
	
	
	
	
	// "/board/"+$("#bno").val()+"/reply/",	
	@ResponseBody //return 이 없으므로... / ajax 사용할때
	@PostMapping("/board/{bno}/reply")
	public void reply(@PathVariable long bno, ReplyWriteDto dto) {
		
		service.save(bno, dto);
		//서비스에게 save 일을 맡기자
		//맡겨야 하니 정보도 같이 보내야 한다.
		//실제 로직 구현은 서비스에서 처리한다.
		//컨트롤은 단지 매핑, 페이지 이돟, 흐름만 제어한다.
	}

}
