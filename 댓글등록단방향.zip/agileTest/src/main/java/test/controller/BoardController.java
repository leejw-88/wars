package test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.BoardWriteDto;
import test.service.BoardService;
import test.service.BoardServiceImpl;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@GetMapping("/board")
	public String board(Model model) {
		//게시글 리스트를 페이지에서 확인하도록 처리
		service.getBoardList(model);		
		return "/board/list";
	}
	
	@GetMapping("/board/write")
	public String wirte() {
		return "/board/write";
	}
	
	//글쓰기 등록하고 나서 리스트로 가는 기능
	//그냥 가면 데이터가 없다
	//정보를 가지고 이동해야한다.
	//return "redirect:/board"; 으로 바꿔준다
	@PostMapping("/board/write")
	public String wirte(BoardWriteDto dto) {
		service.save(dto);
		return "redirect:/board";
	}
	
	//제목을 클릭했을때 지정한 상세 게시글로 가는 기능
	//어떤 게시글을 클릭해도 해당 번호로 갈수 있도록 도와준다.
	@GetMapping("/board/{no}")
	public String detail(@PathVariable long no, Model model) {
		//상세정보를 가지고오는 것을 서비스 임플에 생성한다.
		service.detail(no,model);
		return "/board/detail"; //페이지 이동정보
	}
}
