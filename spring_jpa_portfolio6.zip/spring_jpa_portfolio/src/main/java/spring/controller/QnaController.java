package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import lombok.extern.slf4j.Slf4j;
import spring.service.QnaService;

@Slf4j
@Controller
public class QnaController {
	
	@Autowired
	QnaService qnaService;
	
	//@ResponseBody
	@GetMapping("/board/tapmenu/open/{division}")
	public String list(@PathVariable int division,int page, Model model) {
		log.debug("division : "+division);
		qnaService.list(division, page, model);
		return "/board/tapmenu/listdata";
	}
}
