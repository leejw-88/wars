package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import spring.domain.dto.QnaDto;
import spring.service.QnaService;

@Controller
public class AdminController {
	@Autowired
	private QnaService qnaService;
	
	@GetMapping("/admin/list")
	public String list() {
		return "/admin/list";
	}
	@GetMapping("/admin/qna/write")
	public String qnaWrite() {
		return "/admin/qna/write";
	}
	
	
	@PostMapping("/admin/qna/write")
	public String qnaWrite(QnaDto dto) {
		qnaService.write(dto);
		return "/admin/qna/list";
	}
	@GetMapping("/admin/qna/list")
	public String qnaList() {
		return "/admin/qna/list";
	}
	
	
	@GetMapping("/admin/qna/{division}/{pageNo}")
	public String qnaList(@PathVariable int division,@PathVariable int pageNo, Model model) {//path변수로 받아온다
		System.out.println("division : "+division);
		System.out.println("pageNo : "+pageNo);
		qnaService.getQnaList(division, pageNo, model);
		return "/admin/qna/listdata";
	}
}
