package spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import spring.domain.dto.BoardDto;
import spring.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	/* //////////// 게시판 이동 ///////////////////////// */
	/* 도서관안내 페이지 */
	@GetMapping("/board/tapmenu/Information")
	public String Information() {
		return "/board/tapmenu/Information";
	}
	/* 도서자료 페이지 */
	@GetMapping("/board/tapmenu/material")
	public String material() {
		return "/board/tapmenu/material";
	}
	//열린마당페이지 이동
	//리스트 뿌리기
	@GetMapping("/board/tapmenu/open")
	public String list(Model model) {
		List<BoardDto> boardDtoList = boardService.getBoardList();
		model.addAttribute("postList", boardDtoList);
		return "/board/tapmenu/open";
	}
	//글쓰기페이지 이동
	@GetMapping("/post")
	public String write() {
		return "/board/tapmenu/write";
	}
	//글쓰기 저장
	@PostMapping("/post")
	public String write(@RequestParam("file") MultipartFile files,BoardDto boardDto) {
		try {
			
//            String origFilename = files.getOriginalFilename();
//            String filename = new MD5Generator(origFilename).toString();
//            /* 실행되는 위치의 'files' 폴더에 파일이 저장됩니다. */
//            String savePath = System.getProperty("user.dir") + "\\files";
//            /* 파일이 저장되는 폴더가 없으면 폴더를 생성합니다. */
//            if (!new File(savePath).exists()) {
//                try{
//                    new File(savePath).mkdir();
//                }
//                catch(Exception e){
//                    e.getStackTrace();
//                }
//            }
//            String filePath = savePath + "\\" + filename;
//            files.transferTo(new File(filePath));
//
//            FileDto fileDto = new FileDto();
//            fileDto.setOrigFilename(origFilename);
//            fileDto.setFilename(filename);
//            fileDto.setFilePath(filePath);
//
//            Long fileId = fileService.saveFile(fileDto);
//            boardDto.setFileId(fileId);
            
            boardService.savePost(boardDto);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return "redirect:/board/tapmenu/open";
    }
	@GetMapping("/post/{id}")
	public String detail(@PathVariable("id") Long id, Model model) {
		BoardDto boardDto = boardService.getPost(id);
		model.addAttribute("post", boardDto);
		return "/board/tapmenu/detail";
	}
	
	@GetMapping("/post/edit/{id}")
	public String edit(@PathVariable("id") Long id, Model model) {
		BoardDto boardDto = boardService.getPost(id);
		model.addAttribute("post", boardDto);
		return "/board/tapmenu/edit";
	}
	//main 클래스에 HiddenHttpMethodFilter를 Bean으로 등록하여야 작동
	@PutMapping("/post/edit/{id}") 
	public String update(BoardDto boardDto) {
		boardService.savePost(boardDto);
		return "redirect:/board/tapmenu/open";
	}
	//main 클래스에 HiddenHttpMethodFilter를 Bean으로 등록하여야 작동
	@DeleteMapping("/post/{id}")
    public String delete(@PathVariable("id") Long id) {
        boardService.deletePost(id);
        return "redirect:/board/tapmenu/open";
	}
	
	/* 나의도서관 페이지 */
	@GetMapping("/board/tapmenu/mymenu")
	public String mymenu() {
		return "/board/tapmenu/mymenu";
	}
	
	
	
	
	
	
}
