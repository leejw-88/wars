package spring.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.domain.dto.BoardDto;
import spring.domain.entity.Board;
import spring.domain.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	private BoardRepository boardRepository;
	
	
	//게시글 리스트 불러오기
	@Override
	@Transactional
	public List<BoardDto> getBoardList(){
		List<Board>  boardList = boardRepository.findAll();
		List<BoardDto> boardDtoList = new ArrayList<>();
		
		for(Board board : boardList) {
			BoardDto boardDto = BoardDto.builder()
					.id(board.getId())
					.writer(board.getWriter())
					.title(board.getTitle())
					.content(board.getContent())
					.fileId(board.getFileId())
					.createdDate(board.getUpdatedDate())
					.build();
			boardDtoList.add(boardDto);
		}
		return boardDtoList;
	}


	@Override
	public Long savePost(BoardDto boardDto) {
		return boardRepository.save(boardDto.toEntity()).getId();
		
	}


	@Override
	@Transactional
	public BoardDto getPost(Long id) {
		Board board = boardRepository.findById(id).get();

        BoardDto boardDto = BoardDto.builder()
                .id(board.getId())
                .writer(board.getWriter())
                .title(board.getTitle())
                .content(board.getContent())
                .fileId(board.getFileId())
                .createdDate(board.getCreatedDate())
                .build();
        return boardDto;
	}


	@Override
	@Transactional
	public void deletePost(Long id) {
		boardRepository.deleteById(id);
	}
}
