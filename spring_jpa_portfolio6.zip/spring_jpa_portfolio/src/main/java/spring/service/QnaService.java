package spring.service;

import org.springframework.ui.Model;

import spring.domain.dto.QnaDto;

public interface QnaService {

	void write(QnaDto dto);

	//void list(int division, Model model);
	
	void list(int division, int page, Model model);

	//void getQnaList(int division, Model model);

	void getQnaList(int division, int pageNo, Model model);

}
