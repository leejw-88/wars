package spring.service;

import java.util.List;

import spring.domain.dto.BoardDto;

public interface BoardService {

	List<BoardDto> getBoardList();

	Long savePost(BoardDto boardDto);

	BoardDto getPost(Long id);

	void deletePost(Long id);

}
