package spring.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
public class Board extends BaseDate{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; //pk
	
	@Column(length = 20, nullable = false)
	private String writer; //작성자
	
	@Column(length = 100, nullable = false)
	private String title; //제목
	
	@Column(columnDefinition = "TEXT", nullable = false)
	private String content; //내용
	
	@Column(length = 30)
	private String booktit;
	
	@Column
	private Long view; //조회수
	
	@Column
	private Long fileId; //첨부파일
}
