package test.service;

import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyInsertDto;

public interface ReplyService {

	void save(long bno, ReplyInsertDto dto);

	ModelAndView getReplies(long bno);

}
