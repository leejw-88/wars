package test.service;

import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyDto;
import test.domain.dto.ReplyInsertDto;
import test.domain.entity.BoardEntity;
import test.domain.entity.BoardEntityRepository;
import test.domain.entity.Reply;
import test.domain.entity.ReplyRepository;

@Service
public class ReplyServiceImpl implements ReplyService {
	@Autowired
	BoardEntityRepository boardEntityRepository;
	@Autowired
	ReplyRepository repository;
	
	@Transactional
	@Override
	public void save(long bno, ReplyInsertDto dto) {
		
		//댓글등록 지정된게시글번호, 댓글정보
		System.out.println("---------------------------");
		Reply rEntity=Reply.builder()
				.reply(dto.getReply())
				.writer(dto.getWriter())
				.board(BoardEntity.builder().no(bno).build())
				.build();
		
		repository.save(rEntity);
		
	}

	@Override
	public ModelAndView getReplies(long bno) {
		ModelAndView mv=new ModelAndView("/board/reply");
		/*
		List<Reply> result2=repository.findAllByBoardNo(bno);
		List<ReplyDto> r=new Vector<>();
		for(Reply eitity : result2) {
			r.add(new ReplyDto(eitity));
		}
		*/
		//List<Reply>-->List<ReplyDto>
		//*
		//Sort sort1=Sort.by(Direction.DESC,"no");
		Sort sort=Sort.by("no").descending();
		List<ReplyDto> result=repository.findAllByBoardNo(bno, sort)
								.stream()
								.map(ReplyDto::new)
								.collect(Collectors.toList());
		
		
		mv.addObject("replies", result);
		//*/
		return mv;
	}

}






