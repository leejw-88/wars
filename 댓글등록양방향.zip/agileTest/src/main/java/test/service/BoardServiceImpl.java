package test.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import test.domain.dto.BoardDetailDto;
import test.domain.dto.BoardListDto;
import test.domain.dto.BoardWriteDto;
import test.domain.entity.BoardEntity;
import test.domain.entity.BoardEntityRepository;
import test.domain.entity.ReplyRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardEntityRepository repository;
	@Autowired
	ReplyRepository replyRepository;
	@Transactional
	@Override
	public void getBoardList(Model model) {
		//조회결과 List<BoardListDto> 로 저장
		//페이지에서 확인할수 있도록 Model에 "list"이름으로 저장
		List<BoardListDto> result=repository.findAll().stream()
				.map(BoardListDto::new)
				.collect(Collectors.toList());
		
		model.addAttribute("list", result);
		//for(BoardListDto dto :result) {
			//int a=replyRepository.getCountByBoardNo(dto.getNo());
		//	System.out.println("aaaaaaaaaaaa:" +a);
		//}
		
	}

	@Override
	public void save(BoardWriteDto dto) {
		repository.save(dto.toEntity());
		
	}

	@Override
	public void detail(long no, Model model) {
		
		//BoardEntity result= repository.findById(no).orElseThrow();
		BoardDetailDto result= repository.findById(no)
				.map(BoardDetailDto::new)
				//.map(entity->new BoardDetailDto(entity))
				//.map(entity->{return new BoardDetailDto(entity);})
				.orElseThrow();
		
		model.addAttribute("detail", result);
		
	}

}









