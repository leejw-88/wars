package test.domain.entity.goods;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CategoryName {
	
	SHOES("신발"),
	HANDBAGS("핸드백");
	
	final String title;
	
}
