package test.domain.entity;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ReplyRepository extends JpaRepository<Reply, Long>{

	List<Reply> findAllByBoardNo(long bno);
	List<Reply> findAllByBoardNoOrderByNoDesc(long bno);
	List<Reply> findAllByBoardNo(long bno, Sort sort);
	
	//@Query("select count(r) from Reply r LEFT OUTER JOIN r.board b WHERE b.no=:bno  GROUP BY b")
	//int getCountByBoardNo(@Param("bno") long bno);

}
