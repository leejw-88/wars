package test.domain.entity.goods;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Handbag {
	SHOULDER("숄더백"),
	CROSS("크로스백"),
	MINI("미니백");
	
	final String kind;
}
