package test.domain.entity.goods;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Shose {
	RUNNING("런닝화"),
	FOOTBALL("축구화");
	
	final String kind;
}
