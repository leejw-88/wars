package test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import test.domain.dto.ReplyInsertDto;
import test.service.ReplyService;

@Controller
public class ReplyController {
	// "/board/"+$("#bno").val()+" /reply"
	
	@Autowired
	private ReplyService service;
	
	@ResponseBody
	@GetMapping("/board/{bno}/reply")
	public ModelAndView reply(@PathVariable long bno) {
		//실제로직구현은 service에서 처리
		return service.getReplies(bno);
	}
	
	@ResponseBody
	@PostMapping("/board/{bno}/reply")
	public void reply(@PathVariable long bno, ReplyInsertDto dto) {
		//실제로직구현은 service에서 처리
		service.save(bno, dto);
	}
	
}
