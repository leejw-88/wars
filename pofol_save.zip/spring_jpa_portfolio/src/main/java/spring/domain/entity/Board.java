package spring.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import spring.domain.dto.BoardUpdateDto;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
public class Board extends BaseDate{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; //pk
	@Column(nullable = false)
	private String boardDivision; //게시판 분할
	
	@Column(length = 20)
	private String writer; //작성자
	@Column(length = 100, nullable = false)
	private String title; //제목
	@Column(columnDefinition = "TEXT", nullable = false)
	private String content; //내용
	@Column(length = 30)
	private String booktit; //책 제목
	@Column
	private Long view; //조회수
	@Column
	private Long fileId; //첨부파일
	
	public Board update(BoardUpdateDto dto) {
		title=dto.getTitle();
		content=dto.getContent();
		return this;
	}
}
