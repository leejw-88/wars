package spring.domain.dto;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;
import spring.domain.entity.Board;
import spring.domain.entity.BoardDivision;

@NoArgsConstructor
@Data
public class BoardDto {
	private Long id; //pk
	private String boardDivision; //게시판 분할
	private String writer; //작성자
	private String title; //제목
	private String content; //내용
	private String booktit; //책 제목
	private Long view; //조회수
	private Long fileId; //첨부파일
	private LocalDateTime createdDate; //(가입,생성) 날짜,시간
	private LocalDateTime updatedDate; //최종 수정날짜,시간
	
	public BoardDto(Board board) {
		id=board.getId();
		String _boardDivision=board.getBoardDivision();
		boardDivision=BoardDivision.valueOf(_boardDivision).getTitle();
		writer=board.getWriter();
		title=board.getTitle();
		content=board.getContent();
		booktit=board.getBooktit();
		view=board.getView();
		fileId=board.getFileId();
		createdDate=board.getCreatedDate();
		updatedDate=board.getUpdatedDate();
	}

	public Board toEntity() {
		return Board.builder()
				.id(fileId)
				.boardDivision(boardDivision)
				.writer(writer)
				.title(title)
				.content(content)
				.booktit(booktit)
				.view(view)
				.fileId(fileId)
				.build();
				
	}
}
