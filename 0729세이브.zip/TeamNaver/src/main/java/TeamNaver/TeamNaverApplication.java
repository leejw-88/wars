package TeamNaver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamNaverApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamNaverApplication.class, args);
	}

}
