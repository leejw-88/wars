package TeamNaver.mapper.jyh;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface JyhMapper {
		
	//예시)  메서드명이 xml 쿼리에 id값
	//void save(Dto dto);
}
