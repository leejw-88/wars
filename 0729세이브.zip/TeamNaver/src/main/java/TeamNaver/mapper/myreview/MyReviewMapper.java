package TeamNaver.mapper.myreview;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import TeamNaver.dto.MyReview.MyReviewDto;

@Mapper
public interface MyReviewMapper {
	//목록출력
	public List<MyReviewDto> getList();
	//디테일페이지
	public MyReviewDto myReviewDetail(int no);
	//글쓰기저장
	public void myReviewInsert(MyReviewDto dto);
	//수정
	public void myReviewUpdate(MyReviewDto dto);
	//삭제
	public void myReviewDelete(int no);
	
}
