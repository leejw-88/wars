package TeamNaver.repository.boardRepository;

public class BoardRepository {

}
