package TeamNaver.config;

import javax.sql.DataSource;

//import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

@Configuration 
public class MybatisConfig {
	@Autowired
	DataSource dataSource;
	
	@Autowired
	ApplicationContext applicationContext; //spring 클래스를 import
	
	@Bean
	public SqlSessionFactory sqlSessionFactory() throws Exception {
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		System.out.println("dataSource : "+dataSource);
		//dataSource 세팅
		bean.setDataSource(dataSource); 
		
		//mapper설정								classpath -> src/main/resources
		Resource[] resource=applicationContext.getResources("classpath:/mapper/**/*-mapper.xml");
			// - src/main/resources 경로의 mapper 폴더 하위의 모든 폴더(**) 안의 -mapper.xml로 끝나는 모든 파일
		bean.setMapperLocations(resource); //mapper 설정(xml파일로 했던것)
			// - setMapperLocations 은 Resource... 타입.(cf. ...->가변배열)
		
		return bean.getObject();
	}
	
	 @Bean
	  public SqlSessionTemplate sqlSession() throws Exception {
	    return new SqlSessionTemplate(sqlSessionFactory());
	  }
	
}

//mybatis 설정하려면 이거 복사... mybatis 안쓰면 안써도 되는 애들^^