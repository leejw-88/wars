package TeamNaver.entity.boardEntity;

public class BoardEntity {

}
