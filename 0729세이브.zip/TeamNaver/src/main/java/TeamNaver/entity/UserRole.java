package TeamNaver.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UserRole {
	USER("ROLE_USER", "회원"),
	ADMIN("ROLE_ADMIN","관리자");
	
	private final String role;
	private final String title;
}
