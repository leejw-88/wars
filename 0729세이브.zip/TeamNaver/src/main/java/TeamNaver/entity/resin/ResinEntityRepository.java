package TeamNaver.entity.resin;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ResinEntityRepository extends JpaRepository<ResinEntity, Long>{

}
