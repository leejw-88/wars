package TeamNaver.service.boardService;

public interface BoardService {

}
