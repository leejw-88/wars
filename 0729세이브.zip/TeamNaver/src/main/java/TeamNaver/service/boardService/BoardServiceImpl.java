package TeamNaver.service.boardService;

public class BoardServiceImpl {

}
