package TeamNaver.service.myreviewService;

import java.util.List;

import TeamNaver.dto.MyReview.MyReviewDto;

public interface MyReviewService {
	//목록출력
	public List<MyReviewDto> getList();
	//디테일페이지
	public MyReviewDto myReviewDetail(int no);
	//글쓰기저장
	public void myReviewInsert(MyReviewDto dto);
	//수정
	public void myReviewUpdate(MyReviewDto dto);
	//삭제
	public void myReviewDelete(int no);
}
