package TeamNaver.service.myreviewService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import TeamNaver.dto.MyReview.MyReviewDto;
import TeamNaver.mapper.myreview.MyReviewMapper;

@Service
public class MyReviewServiceImpl implements MyReviewService{
	@Autowired
	MyReviewMapper myReviewMapper;
	//리스트출력
	@Override
	public List<MyReviewDto> getList() {
		return myReviewMapper.getList();
	}
	//상세페이지
	@Override
	public MyReviewDto myReviewDetail(int no) {
		return myReviewMapper.myReviewDetail(no);
	}
	//저장
	@Override
	public void myReviewInsert(MyReviewDto dto) {
		myReviewMapper.myReviewInsert(dto);
		
	}
	//수정
	@Override
	public void myReviewUpdate(MyReviewDto dto) {
		myReviewMapper.myReviewUpdate(dto);
		
	}
	//삭제
	@Override
	public void myReviewDelete(int no) {
		myReviewMapper.myReviewDelete(no);
		
	}


	
}
