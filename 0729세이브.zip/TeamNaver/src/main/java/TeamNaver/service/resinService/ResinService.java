package TeamNaver.service.resinService;

import org.springframework.ui.Model;

import TeamNaver.dto.resin.ResinWriteDto;

public interface ResinService {

	void save(ResinWriteDto dto);

	void getResinList(Model model);

}
