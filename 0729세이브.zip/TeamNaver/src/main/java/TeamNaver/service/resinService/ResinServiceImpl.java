package TeamNaver.service.resinService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import TeamNaver.dto.resin.ResinListDto;
import TeamNaver.dto.resin.ResinWriteDto;
import TeamNaver.entity.resin.ResinEntityRepository;

@Service
public class ResinServiceImpl implements ResinService {

	@Autowired
	private ResinEntityRepository repository;
	
	@Override
	public void save(ResinWriteDto dto) {
		repository.save(dto.toEntity());
		
	}
	
	@Override
	public void getResinList(Model model) {
		List<ResinListDto> result=repository.findAll().stream()
							.map(ResinListDto::new)
							.collect(Collectors.toList());
		model.addAttribute("list", result);
		
	}

	
	
}
