package TeamNaver.dto.resin;

import java.time.LocalDateTime;

import TeamNaver.entity.resin.ResinEntity;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public class ResinListDto {
	
	private long no;
	private String subject;
	private String content;
	private String writer;
	private LocalDateTime createdDate;
	
	public ResinListDto(ResinEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content = entity.getContent();
		this.writer = entity.getWriter();
		this.createdDate = entity.getCreatedDate();
	}
	
	
}
