package TeamNaver.dto.resin;

import TeamNaver.entity.resin.ResinEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class ResinWriteDto {
	private String subject;
	private String content;
	private String writer;
	
	public ResinEntity toEntity() {
		return ResinEntity.builder()
							.subject(subject)
							.content(content)
							.writer(writer)
							.build();
	}
	
}
