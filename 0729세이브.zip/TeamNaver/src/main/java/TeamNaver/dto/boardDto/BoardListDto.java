package TeamNaver.dto.boardDto;

public class BoardListDto {

}
