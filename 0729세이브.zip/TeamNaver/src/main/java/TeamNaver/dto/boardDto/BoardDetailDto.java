package TeamNaver.dto.boardDto;

public class BoardDetailDto {

}
