package TeamNaver.dto.boardDto;

public class BoardWriteDto {

}
