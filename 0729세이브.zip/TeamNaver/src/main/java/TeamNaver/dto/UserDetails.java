package TeamNaver.dto;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;

@Getter
public class UserDetails extends User{
	
	private String name;
	
	public UserDetails(TeamNaver.entity.User entity) {
		super(entity.getUserId(), entity.getPassword(), 
				entity.getRoles().stream().map(role->new SimpleGrantedAuthority(role.getRole())).collect(Collectors.toSet()));
		
		name=entity.getName();
	}
	
}
