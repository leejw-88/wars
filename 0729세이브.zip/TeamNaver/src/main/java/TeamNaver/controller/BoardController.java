package TeamNaver.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BoardController {

	
	//커밋테스트
	public void test() {
		
	}
	
}
