package TeamNaver.controller.myreviewcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import TeamNaver.dto.MyReview.MyReviewDto;
import TeamNaver.service.myreviewService.MyReviewService;

@org.springframework.stereotype.Controller
public class MyReviewController {
	
	@Autowired
	MyReviewService myReviewService;
	//list페이지 출력
	@GetMapping("/myreview/list") 
	public ModelAndView MyReviewList() throws Exception { 
		ModelAndView mv = new ModelAndView("/myreview/list"); //view를 설정해준다. 
		List<MyReviewDto> list = myReviewService.getList(); //service를 이용하여게시판 목록을 데이터베이스에서 조회한다. 
		mv.addObject("list",list); //설정한 뷰로 넘겨줄 데이터를 추가
		return mv; 
	}
	//디테일 페이지 이동
	@GetMapping("/myreview/detail/{no}")
	public String MyReviewWrite(@PathVariable int no, Model model){
		model.addAttribute("detail", myReviewService.myReviewDetail(no));
		return "/myreview/write";
	}
	//글쓰기 페이지 이동
	@GetMapping("/myreview/write")
	public String MyReviewWrite(){
		return "/myreview/write";
	}
	//글쓰기 저장
	@PostMapping("/myreview/insert")
	public String MyReviewInsert(MyReviewDto dto){
		myReviewService.myReviewInsert(dto);
		return "redirect:/myreview/list";
	}
}