package TeamNaver.controller.resincontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import TeamNaver.dto.resin.ResinWriteDto;
import TeamNaver.service.resinService.ResinService;

@Controller
public class ResinController {

	@Autowired
	private ResinService service;
	
	@GetMapping("/resin/list")
	public String list(Model model) {
		service.getResinList(model);
		return "/resin/list"; 
	}
	
	@GetMapping("/resin/write")
	public String write() {
		return "/resin/write";
	}
	
	@PostMapping("/resin/write")
	public String insert(ResinWriteDto dto ) {
		service.save(dto);
		return "redirect:/resin/list";
	}
	
}
