package TeamNaver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import TeamNaver.dto.SignupDto;
import TeamNaver.service.SignupService;

@Controller
public class UserController {
	
	@Autowired
	SignupService signupService;
	
	@PostMapping("/user/signup")
	public String signup(SignupDto dto) {
		signupService.signup(dto);
		return "/user/login";
	}
}
