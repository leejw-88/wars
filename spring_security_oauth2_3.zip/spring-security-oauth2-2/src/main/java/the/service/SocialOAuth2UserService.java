package the.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import the.domain.dto.MemberDetails;
import the.domain.entity.Member;
import the.domain.entity.MemberRepository;
import the.domain.entity.MemberRole;

@Service
public class SocialOAuth2UserService extends DefaultOAuth2UserService {
	
	@Autowired
	private PasswordEncoder encoder;
	@Autowired
	MemberRepository repository;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oAuth2User = super.loadUser(userRequest);
		String registrationId=userRequest.getClientRegistration().getRegistrationId();
		
		return saveSocialMember(registrationId,oAuth2User); 
	}

	private MemberDetails saveSocialMember(String registrationId, OAuth2User oAuth2User) {
		String email=null;
		String name=null;
		if(registrationId.equals("naver")) {
			Map<String,String> info=(Map<String,String>)oAuth2User.getAttribute("response");
			email=info.get("email");
			name=info.get("name");
		}else {
			email = oAuth2User.getAttribute("email");
			name = oAuth2User.getAttribute("name");
		}
		
		Member entity = Member.builder()
								.name(name)
								.email(email)
								.nickName(name)
								.isSocial(true)
								.password(encoder.encode("social"+(System.nanoTime()/100000000)))
								.build();
		entity.addRole(MemberRole.USER);
		
		Member result = repository.save(entity);
		
		return new MemberDetails(result);
	}

}
