package spring.domain.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import spring.domain.entity.Board;


@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BoardDto {
	private Long id; //pk
	private String boardDivision; //게시판 분할
	private String writer; //작성자
	private String title; //제목
	private String content; //내용
	private String booktit; //책 제목
	private Long view; //조회수
	private Long fileId; //첨부파일
	private LocalDateTime createdDate; //(가입,생성) 날짜,시간
	private LocalDateTime updatedDate; //최종 수정날짜,시간
	
	
	public Board toEntity() {
		return Board.builder()
				.id(fileId)
				.boardDivision(boardDivision)
				.writer(writer)
				.title(title)
				.content(content)
				.booktit(booktit)
				.view(view)
				.fileId(fileId)
				.build();
				
	}
}
