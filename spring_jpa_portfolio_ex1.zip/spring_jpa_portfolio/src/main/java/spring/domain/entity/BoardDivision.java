package spring.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum BoardDivision {
	greetings("인사말"),			//0
	InformationUse("이용안내"),	//1
	notice("공지사항"),			//2
	qna("묻고답하기"),				//3
	bookReview("독서감상문"),		//4
	requestedBook("희망도서");	//5
	
	final String title;
}
