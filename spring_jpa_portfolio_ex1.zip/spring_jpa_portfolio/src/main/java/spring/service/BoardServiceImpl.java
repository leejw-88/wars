package spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.domain.dto.BoardDto;
import spring.domain.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardRepository boardRepository;

	@Override
	public void saveWrite(BoardDto boardDto) {
		boardRepository.save(boardDto.toEntity());
	}

	// 관리자페이지 글쓰기 저장
	@Override
	public void boardWrite(BoardDto boardDto) {
		boardRepository.save(boardDto.toEntity());
	}
	// board 리스트 불러오기

}
