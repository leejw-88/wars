package spring.service;

import spring.domain.dto.BoardDto;

public interface BoardService {

	void boardWrite(BoardDto dto); // 관리자페이지 글쓰기저장

	void saveWrite(BoardDto boardDto); //board 글쓰기 저장


	


}
