package spring.service;

import spring.domain.dto.CategoryDto;

public interface CategoryService {

	void save(CategoryDto dto);

}
