package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import spring.domain.dto.CategoryDto;
import spring.service.CategoryService;

@Controller
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
	
	@GetMapping("/admin/category")
	public String category() {
		return "/admin/category/write";
	}
	
	@PostMapping("/admin/category")
	public String category(CategoryDto dto) {
		categoryService.save(dto);
		return "/admin/category/write";
	}
}
