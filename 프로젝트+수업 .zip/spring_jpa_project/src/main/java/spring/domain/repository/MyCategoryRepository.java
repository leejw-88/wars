package spring.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import spring.domain.entity.MyCategory;

public interface MyCategoryRepository extends JpaRepository<MyCategory, Integer>{

	@Query("select max(first) FROM MyCategory mc")
	int getMaxValueFirst();

}
