package spring;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.domain.entity.Division;
import spring.domain.entity.Member;
import spring.domain.entity.MemberRepository;
import spring.domain.entity.MemberRole;
import spring.domain.entity.QnaEntity;
import spring.domain.entity.QnaEntityRepository;

@SpringBootTest
class SpringSecurityOauth2FApplicationTests {
	@Autowired
	PasswordEncoder	passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	QnaEntityRepository qnaEntityRepository;
	
	
	//@Test
	void faq데이터삽입() {
		
		//Division.values(); //enum요소들을 순서대로 배열
		for(Division div:Division.values()) {
			IntStream.rangeClosed(1, 20).forEach(i->{
				QnaEntity entity=QnaEntity.builder()
						.division(div.name())
						.question(div.getTitle()+" 질문"+i)
						.answer(div.getTitle()+" 답변"+i)
						.build();
				qnaEntityRepository.save(entity);
			});
		}
	}
	
	
	//@Test
	void 관리자아이디생성() {
		
			Member entity=Member.builder()
					.email("admin@test.com")
					.name("관리자")
					.password(passwordEncoder.encode("1234"))
					.phone("0101234567")
					.build();
			entity.addRole(MemberRole.USER);
			entity.addRole(MemberRole.ADMIN);
			memberRepository.save(entity);
	}

	
	
	
}