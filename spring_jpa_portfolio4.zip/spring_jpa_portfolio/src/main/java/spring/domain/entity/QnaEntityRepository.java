package spring.domain.entity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaEntityRepository extends JpaRepository<QnaEntity, Long>{

	//List<QnaEntity> findAllByDivisionOrderByNoDesc(String division);

	Page<QnaEntity> findAllByDivision(String name, Pageable pageable);

}
