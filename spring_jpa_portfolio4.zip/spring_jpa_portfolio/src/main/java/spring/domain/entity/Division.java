package spring.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Division {
	movie("영화관 이용"),	//0
	lpoint("L.POINT"),	//1
	member("회원"),		//2
	membership("멤버쉽"),	//3
	online("온라인"),		//4
	discount("할인혜택"),	//5
	ticket("관람권"),		//6
	store("스토어"),		//7
	spcail("스페셜관");	//8
	
	final String title;
}
