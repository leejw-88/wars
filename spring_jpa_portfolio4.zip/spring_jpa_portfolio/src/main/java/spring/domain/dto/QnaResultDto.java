package spring.domain.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import spring.domain.entity.Division;
import spring.domain.entity.QnaEntity;

@NoArgsConstructor
@Data
public class QnaResultDto {
	private long no;
	private String division;
	private String question;
	private String answer;
	
	public QnaResultDto(QnaEntity entity) {
		no=entity.getNo();
		String _division=entity.getDivision();
		
		division=Division.valueOf(_division).getTitle();
		question=entity.getQuestion();
		answer=entity.getAnswer();
	}
}
