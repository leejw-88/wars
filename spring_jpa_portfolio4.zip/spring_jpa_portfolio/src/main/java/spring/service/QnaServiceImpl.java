package spring.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring.domain.dto.QnaDto;
import spring.domain.dto.QnaResultDto;
import spring.domain.entity.Division;
import spring.domain.entity.QnaEntity;
import spring.domain.entity.QnaEntityRepository;

@Service
public class QnaServiceImpl implements QnaService{


	@Autowired
	private QnaEntityRepository qnaEntityRepository;
	@Override
	public void write(QnaDto dto) {
		qnaEntityRepository.save(dto.toEntity());
		
	}
	@Override
	public void list(int division,int page, Model model) {
		
		Division div=Division.values()[division];
		//Division[] arr=Division.values();
		//Division div=arr[division];
		
		//쿼리메서드
		//키워드 OrderBy
		//desc
		Sort sort = Sort.by(Direction.DESC,"no");
		Pageable pageable = PageRequest.of(page-1, 4, sort);
		//qnaEntityRepository.findAll(pageable);
		Page<QnaEntity> result=qnaEntityRepository.findAllByDivision(div.name(),pageable);
		int pageTot=result.getTotalPages();
		//System.out.println(pageTot);
		model.addAttribute("to", pageTot);
		
		
		List<QnaResultDto> list = result.getContent()
			.stream()
			.map(QnaResultDto::new)// entity->new QnaResultDto(entity) 
			.collect(Collectors.toList());
		
		model.addAttribute("list", list);
		
	}
	
}
