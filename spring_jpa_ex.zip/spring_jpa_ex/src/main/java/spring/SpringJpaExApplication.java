package spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.web.filter.HiddenHttpMethodFilter;

@EnableJpaAuditing
@SpringBootApplication
public class SpringJpaExApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringJpaExApplication.class, args);
	}
	
	//@PutMapping과 @DeleteMapping 사용하기위해 @Bean등록
	@Bean
	public HiddenHttpMethodFilter hiddenHttpMethodFilter() {
		return new HiddenHttpMethodFilter();
	};
}
