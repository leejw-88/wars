package spring.domain.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;
import spring.domain.entity.Board;

@Data
public class BoardDto {
	private Long id;
	private String writer;
	private String title;
	private String content;
	private Long fileId;
	private LocalDateTime createdDate;
	private LocalDateTime modifiedDate;
	
	public Board toEntity() {
		return Board.builder()
				.id(id)
				.writer(writer)
				.title(title)
				.content(content)
				.fileId(fileId)
				.build();
	}
	@Builder
	public BoardDto(Long id, String writer, String title, String content, Long fileId, LocalDateTime createdDate,
			LocalDateTime modifiedDate) {
		this.id = id;
		this.writer = writer;
		this.title = title;
		this.content = content;
		this.fileId = fileId;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
	}
	
}
