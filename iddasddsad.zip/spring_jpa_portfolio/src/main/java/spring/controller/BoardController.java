package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import spring.domain.dto.BoardDto;
import spring.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;

	/* //////////// 게시판 이동 ///////////////////////// */
	// 리스트 뿌리기
	/* 도서관안내 페이지 */
	@GetMapping("/board/tapmenu/Information/{boardDvision}")
	public String Information(@PathVariable int boardDivision,int page, Model model) {
		boardService.getList(boardDivision,page,model);
		return "/board/tapmenu/Information";
	}

	/* 도서자료 페이지 */
	@GetMapping("/board/tapmenu/material")
	public String material() {
		return "/board/tapmenu/material";
	}

	/* 열린마당 페이지 */
	@GetMapping("/board/tapmenu/open")
	public String open() {
		return "/board/tapmenu/open";
	}

	/* 나의도서관 페이지 */
	@GetMapping("/board/tapmenu/mymenu")
	public String mymenu() {
		return "/board/tapmenu/mymenu";
	}

	///////////////////////////////////////////
	// 글쓰기 게시판 이동
	@GetMapping("/post")
	public String write() {
		return "board/write";
	}

	// 글쓰기 저장
	@PostMapping("/post")
	public String write(BoardDto boardDto) {
		boardService.saveWrite(boardDto);
		return "board/write";
	}
	
}
