package spring;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.domain.entity.Board;
import spring.domain.entity.BoardDivision;
import spring.domain.entity.Member;
import spring.domain.entity.MemberRepository;
import spring.domain.entity.MemberRole;
import spring.domain.repository.BoardRepository;

@SpringBootTest
class SpringSecurityOauth2FApplicationTests {
	@Autowired
	PasswordEncoder	passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	BoardRepository boardRepository;
	
	//@Test
	void 데이터삽입() {
		
		//Division.values(); //enum요소들을 순서대로 배열
		for(BoardDivision div:BoardDivision.values()) {
			IntStream.rangeClosed(1, 20).forEach(i->{
				Board entity=Board.builder()
						.boardDivision(div.name())
						.writer(div.getTitle()+" 작성자"+i)
						.title(div.getTitle()+" 제목"+i)
						.content(div.getTitle()+" 내용"+i)
						.build();
				boardRepository.save(entity);
			});
		}
	}
	
	
	//@Test
	void 관리자아이디생성() {
		
			Member entity=Member.builder()
					.email("admin@test.com")
					.name("관리자")
					.password(passwordEncoder.encode("1234"))
					.phone("0101234567")
					.build();
			entity.addRole(MemberRole.USER);
			entity.addRole(MemberRole.ADMIN);
			memberRepository.save(entity);
	}

	
	
	
}