/**
 * 
 */
$(function(){
	//마우스 오버시 실행하는 함수
	$(".tap-wrap>li>.tap-tit").hover(hoverMenu,removeMenu);
	//마우스클릭시 실행하는 함수
	$("button[name=tap1]").click(tapButton1);
	$("button[name=tap2]").click(tapButton2);
	$("button[name=tap3]").click(tapButton3);
	$("button[name=tap4]").click(tapButton4);

/////////////////////////////////////////////////////////
	var pageNo=1; //페이지번호를 저장하는 변수
	var div=0;	  //division 정보를 저장하는 변수
	$(function(){
		getBoardList(div);	//페이지 로딩시 0번인덱스페이지
		$(".tap-navi>button").click(function(){ //클릭시 처리되는 함수
			pageNo=1;//페이지번호 1번으로 초기화
			div=$(this).index();
			getBoardList(div)
		}); 
	});
	
	function getBoardList(boardDivision){ // boardDivision=div
		$.ajax({
			url:"/board/open/"+boardDivision+"/"+pageNo,
			type:"get",
			data:{"pageNo" : pageNo},
			success:function(result){//result : tapmenu->listdata
				$("#listdata").html(result);
				/* listdata.html 소스가 적용됩니다. */
				$(function(){
					$("#pagging button").click(function(){
						pageNo=$(this).text().trim();
						getBoardList(div);
					});
				});
			}
		});
	}

});


//////////////////////////////////////////////////////////////
function hoverMenu(){
	$(this).addClass("hover-tit");
}
function removeMenu(){
 	$(".tap-wrap>li>.tap-tit").removeClass("hover-tit");
}

function tapButton1(){
	$(location).attr("href", "/board/Information");
}
function tapButton2(){
	$(location).attr("href", "/board/material");
}
function tapButton3(){
	$(location).attr("href", "/board/open");
}
function tapButton4(){
	$(location).attr("href", "/board/mymenu");
}