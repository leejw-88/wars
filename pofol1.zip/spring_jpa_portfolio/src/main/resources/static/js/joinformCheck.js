/**
 * 
 */
$(function(){
	$("#joinformCheck").click();
});

function joinformCheck(){
	var email = document.getElementById("email");
	var password = document.getElementById("password");
	var passwordPin = document.getElementById("passwordPin");
	var name = document.getElementById("name");
	var phone = document.getElementById("phone");
	
	if(email.value ==""){//해당 입력값이 없을경우
		alert("이메일을 입력하세요.");//메세지 띄움
		email.focus();//커서가깜빡임
		return false;//반환하는값 없음 코드진행 멈춤
	}
	if(password.value ==""){
		alert("비밀번호를 입력하세요.");
		password.focus();
		return false;
	}
	//비밀번호 영문자+숫자+특수문자 조합(8~20자리 입력) 정규식
	var passwordCheck = /^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{8,20}$/;
	if(!passwordCheck.test(password.value)){
		alert("비밀번호는 영문자+숫자+특수문자 조합으로8~20자리 사용해야 합니다.");
		password.focus();
		return false;
	}
	if(password.value !== passwordPin.value){
		alert("비밀번호가 일치하지 않습니다.");
		password.focus();
		return false;
	}
	if(name.value ==""){
		alert("이름을 입력하세요.");
		name.focus();
		return false;
	}
	//숫자만 입력하는 정규식
	var reg = /^[0-9]+/g;
	if(reg.test(phone.value)){
		alert("전화번호는 숫자만 입력할 수 있습니다.");
		phone.focus();
		return false;
	}
	//입력 값 전송
	document.joinform.submit();
}