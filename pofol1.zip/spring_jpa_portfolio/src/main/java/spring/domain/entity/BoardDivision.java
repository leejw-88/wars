package spring.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum BoardDivision {
	notice("공지사항"),			//0
	qna("묻고답하기"),				//1
	bookReview("독서감상문"),		//2
	requestedBook("희망도서");	//3
	
	final String title;
}
