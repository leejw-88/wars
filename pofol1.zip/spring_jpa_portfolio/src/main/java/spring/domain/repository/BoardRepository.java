package spring.domain.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import spring.domain.entity.Board;

public interface BoardRepository extends JpaRepository<Board, Long>{

	Page<Board> findAllByBoardDivision(String name, Pageable pageable);

	void findAllByBoardDivision(String name);


}
