package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import spring.domain.dto.BoardDto;
import spring.service.BoardService;

@Controller
public class AdminController {
	@Autowired
	private BoardService boardService;
	
	@GetMapping("/admin/list")
	public String list() {
		return "/admin/list";
	}
	@GetMapping("/admin/qna/boardwrite")
	public String boardWrite() {
		return "/admin/qna/boardwrite";
	}
	@PostMapping("/admin/qna/boardwrite")
	public String boardwrite(BoardDto dto) {
		boardService.boardWrite(dto);
		return "/admin/qna/boardwrite";
	}
	@GetMapping("/admin/qna/boardlist")
	public String boardList() {
		return "/admin/qna/boardlist";
	}
	@ResponseBody
	@DeleteMapping("/admin/qna/boardlist/{id}")
	public void qnaBoardDelete(@PathVariable long id) {
		System.out.println("no"+id);
		boardService.delete(id);
	}
	///// 리스트 불러오기 //////////////////////////
//	@ResponseBody
//	@GetMapping("/admin/qna/boardlist/{boardDivision}/{pageNo}")
//	public String boardList(@PathVariable int boardDivision,@PathVariable int pageNo, ModelAndView mv) {
//		boardService.getList(boardDivision,pageNo,mv);
//		return "/admin/qna/boardlistdata";
//	}
	@GetMapping("/admin/qna/boardlist/{boardDivision}/{pageNo}")
	public String boardList(@PathVariable int boardDivision,@PathVariable int pageNo, Model model) {
		boardService.getList(boardDivision,pageNo,model);
		return "/admin/qna/boardlistdata";
	}
	
	
}
