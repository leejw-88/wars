package spring.service.api;

import java.util.List;

import spring.domain.dto.api.BookSearch;

public interface BookSearchApiService {
	
	List<BookSearch> getBookSearchList();
}
