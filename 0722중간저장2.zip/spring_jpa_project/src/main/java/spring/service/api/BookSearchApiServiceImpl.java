package spring.service.api;

import java.util.List;

import org.springframework.stereotype.Service;

import spring.domain.dto.api.BookSearch;

@Service
public class BookSearchApiServiceImpl implements BookSearchApiService{

	@Override
	public List<BookSearch> getBookSearchList() {
        
		return null;
	}

}
