package spring.domain.dto.api;

import lombok.Data;

@Data
public class BookSearch {
	
}
