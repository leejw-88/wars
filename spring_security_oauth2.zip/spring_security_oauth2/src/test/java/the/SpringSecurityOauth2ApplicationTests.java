package the;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOauth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
