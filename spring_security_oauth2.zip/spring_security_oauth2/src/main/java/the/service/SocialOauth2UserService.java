package the.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import the.domain.dto.OAuthMember;
import the.domain.entity.Member4;
import the.domain.entity.MemberRepository;
import the.domain.entity.MemberRole4;

//구글로그인 이후 사용자 정보를 저장하거나 세션등 기능을 처리하기위해...
@Slf4j
@Service
public class SocialOauth2UserService extends DefaultOAuth2UserService{
	
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		String clientName=userRequest.getClientRegistration().getClientName();
		log.debug("------------------------------");
		log.debug("clientName : "+clientName);
		OAuth2User oAuth2User=super.loadUser(userRequest);
	
		return 	saveSocailMember(oAuth2User); 
	}

	private OAuth2User saveSocailMember(OAuth2User oAuth2User) {
		/*
		Map<String, Object> map=oAuth2User.getAttributes();
		log.debug("------------------------------");
		map.keySet().stream().forEach(key->{
			log.debug(key+" : "+map.get(key));
		});
		log.debug("------------------------------");
		*/
		
		String email=(String)oAuth2User.getAttribute("email");
		String name=(String)oAuth2User.getAttribute("name");
		
		Member4 entity=Member4.builder()
				.email(email)
				.pass(passwordEncoder.encode("socailuser"))
				.isSocial(true)
				.name(name)
				.role(MemberRole4.USER)
				.build();
		Member4 result=memberRepository.save(entity);
		
		Set<SimpleGrantedAuthority> set=new HashSet<>();
		set.add(new SimpleGrantedAuthority(MemberRole4.USER.getRole()));
		
		return new OAuthMember(result.getEmail(), result.getPass(), set);
	}
	
	
	
	
}
