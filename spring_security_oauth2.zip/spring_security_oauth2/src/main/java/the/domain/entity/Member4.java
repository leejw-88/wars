package the.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Entity
public class Member4 extends BaseDate{
	
	@Id
	private String email;
	@Column(nullable = false)
	private String pass;
	@Column(nullable = false)
	private String name;
	
	@Column
	private boolean isSocial;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private MemberRole4 role;
	
	public String getRole() {
		return role.getRole();
	}
}
