package the.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum MemberRole4 {
	
	USER("ROLE_USER","회원"),  	//0
	ADMIN("ROLE_ADMIN","관리자"); //1
	
	private final String role;
	private final String title;
}
