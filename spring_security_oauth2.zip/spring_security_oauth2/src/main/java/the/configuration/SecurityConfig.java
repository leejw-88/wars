package the.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import the.service.SocialOauth2UserService;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	SocialOauth2UserService socialOauth2UserService;
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.
			authorizeRequests()
				.antMatchers("/","/log/**").permitAll()
				.antMatchers("/user/**").hasRole("USER")
				.antMatchers("/admin/**").hasRole("ADMIN")
				.anyRequest().authenticated();
		//http.csrf().disable();
		http.
			formLogin()
				.loginPage("/log/loin")		  // 로그인 url
				.loginProcessingUrl("/login") // action=""
				.usernameParameter("email")	  // username
				.passwordParameter("pass");	  // password
		http.oauth2Login()
				.userInfoEndpoint()//로그인성공이후 사용자정보를 가져올때 설정
					.userService(socialOauth2UserService);
		http.logout().logoutSuccessUrl("/");
	}
	
	
}
