/**
 * 
 */
$(function(){
	$("#notice").click(function(){
		alert("asdsa");
	});
});