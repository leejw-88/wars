package spring.service;

import org.springframework.ui.Model;

import spring.domain.dto.ReviewDto;

public interface ReviewService {

	void getBookReviewList(int pageNo, Model model);// 도서감상문 리스트 출력
	
	void bookReviewDelete(long no);// 도서감상문 글 삭제

	void bookReviewWrite(ReviewDto dto);// 도서감상문 글쓰기

	ReviewDto getDetails(Long no);// 도서감상문 디테일페이지

}
