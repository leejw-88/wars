package spring.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring.domain.dto.ReviewDto;
import spring.domain.entity.Review;
import spring.domain.repository.ReviewRepository;

@Service
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewRepository reviewRepository;
	//도서감상문 리스트 출력
	@Override
	public void getBookReviewList(int pageNo, Model model) {
		Sort sort=Sort.by(Direction.DESC,"updatedDate");
		Pageable pageable=PageRequest.of(pageNo-1,5, sort);
		Page<Review> result = reviewRepository.findAll(pageable);
		int pagetotal=result.getTotalPages();
		//출력하기위해 배열로 바꿈
		List<ReviewDto> list=
				result.getContent() //NoticeDto에 있는 객체를 List타입으로 
				.stream().map(ReviewDto::new)//entity -> new BoardDto(entity)
				.collect(Collectors.toList());
		
		model.addAttribute("bookReviewList", list);
		model.addAttribute("pagetotal", pagetotal);
	}
	//도서감상문 글쓰기 저장
	@Override
	public void bookReviewWrite(ReviewDto dto) {
		reviewRepository.save(dto.toEntity());
		
	}
	//도서감상문 글 삭제
	@Override
	public void bookReviewDelete(long no) {
		reviewRepository.deleteById(no);
	}
	//디테일페이지 출력
	@Override
	public ReviewDto getDetails(Long no) {
		Review review = reviewRepository.findById(no).get();
		
		ReviewDto reviewDto = ReviewDto.builder()
                .no(review.getNo())
                .bookName(review.getBookName())
                .author(review.getAuthor())
                .title(review.getTitle())
                .content(review.getContent())
                .writer(review.getWriter())
                .view(review.getView())
                .createdDate(review.getCreatedDate())
                .build();
        return reviewDto;
	}

	

}
