package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.extern.slf4j.Slf4j;
import the.domain.entity.Member3;
import the.domain.entity.MemberRepository;
import the.domain.entity.MemberRole;

@Slf4j
@SpringBootTest
class SpringSecurityTest03ApplicationTests {
	
	@Autowired
	PasswordEncoder encoder;
	@Autowired
	MemberRepository memberRepository;
	
	@Test
	void contextLoads() {
		log.info("임시 회원정보 입력");
		IntStream.rangeClosed(1, 3).forEach(i->{
			Member3 entity=Member3.builder()
							.email("test"+i+"@test.com")
							.pass(encoder.encode("1234"))
							.name("회원"+i)
							.build();
			entity.addRole(MemberRole.USER);
			if(i==3) {
				entity.addRole(MemberRole.ADMIN);
			}
			
			memberRepository.save(entity);
			
		});
		
	}

}
