package the.domain.dto;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import the.domain.entity.Member3;

@Getter
public class MemberDetail extends User {
	private String name;
	public MemberDetail(Member3 entity) {
		super(entity.getEmail(), entity.getPass(), 
				entity.getRoles().stream()
				.map(role->new SimpleGrantedAuthority(role.getRole()))
				.collect(Collectors.toSet()));
		
		//enum MemberRole -> new SimpleGrantedAuthority
		name=entity.getName();
	}

}
