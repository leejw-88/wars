package the.domain.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Entity
public class Member3 extends BaseDate{
	
	@Id
	private String email;
	
	@Column(nullable = false)
	private String pass;
	@Column(nullable = false)
	private String name;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@Enumerated(EnumType.STRING)
	@Builder.Default
	private Set<MemberRole> roles=new HashSet<>();
	public void addRole(MemberRole role) {
		roles.add(role);
	}
}
