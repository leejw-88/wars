package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class PageController {
	
	@GetMapping("/log/login")
	public String login() {
		/*
		log.debug("debug레벨출력");
		log.info("info레벨출력");
		log.warn("warn");
		log.error("error");
		*/
		return "/log/login";
	}
}
