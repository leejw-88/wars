package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import spring.domain.dto.BoardDto;
import spring.domain.dto.BoardUpdateDto;
import spring.service.BoardService;

@Controller
public class AdminController {
	@Autowired
	private BoardService boardService;
	
	// 페이지 이동 ////////////
	@GetMapping("/admin/list")
	public String adminList() {
		return "/admin/list";
	}
	@GetMapping("/admin/qna/boardwrite")
	public String boardWrite() {
		return "/admin/qna/boardwrite";
	}
	@PostMapping("/admin/qna/boardwrite")
	public String boardwrite(BoardDto dto) {
		boardService.boardWrite(dto);
		return "/admin/qna/boardwrite";
	}
	@GetMapping("/admin/qna/boardlist")
	public String adminBoardList() {
		return "/admin/qna/boardlist";
	}
	// 리스트 불러오기 //////////////////////////
	/*
	@GetMapping("/admin/qna/boardlist/{boardDivision}/{pageNo}")
	public String boardList(@PathVariable int boardDivision,@PathVariable int pageNo,  Model model) {
		boardService.getList(boardDivision,pageNo,model);
		return "/admin/qna/boardlistdata";
	}
	*/
	@ResponseBody
	@GetMapping("/admin/qna/boardlist/{boardDivision}/{pageNo}")
	public ModelAndView boardList(@PathVariable int boardDivision,@PathVariable int pageNo,  ModelAndView mv) {
		System.out.println("division : "+boardDivision);
		System.out.println("pageNo : "+pageNo);
		//boardService.getList(division , pageNo, model);
		boardService.getAdminList(boardDivision,pageNo,mv);
		mv.setViewName("/admin/qna/boardlistdata");
		return mv;
	}
	//관리자페이지 삭제처리
	@ResponseBody
	@DeleteMapping("/admin/qna/boardlist/{id}")
	public void adminDelete(@PathVariable long id) {
		System.out.println("delete-no:"+id);
		boardService.delete(id);
	}
	//관리자페이지 수정처리
	@ResponseBody
	@PutMapping("/admin/qna/boardlist/{id}")
	public void adminUpdate(@PathVariable long id,BoardUpdateDto dto) {
		System.out.println("edit-no:"+id);
		//System.out.println("edit-no:"+dto.getTitle());
		//System.out.println("edit-no:"+dto.getContent());
		boardService.update(id,dto);

	}
	
}
