package spring.service;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import spring.domain.dto.BoardDto;
import spring.domain.dto.BoardUpdateDto;

public interface BoardService {

	void boardWrite(BoardDto dto); // 관리자페이지 글쓰기저장

	void saveWrite(BoardDto boardDto); //board 글쓰기 저장

	void getList(int boardDivision, int pageNo, Model model); //board 리스트불러오기
	
	
	void getAdminList(int boardDivision, int pageNo, ModelAndView mv); //관리자 리스트 불러오기

	void delete(long id); //관리자 글삭제

	void update(long id, BoardUpdateDto dto);



	

}
