package spring.domain.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import spring.domain.entity.Notice;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class NoticeDto {
	private long no;
	private String title;
	private String content;
	private String writer;
	private long view;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	
	public NoticeDto (Notice notice) {
		no=notice.getNo();
		title=notice.getTitle();
		content=notice.getContent();
		writer=notice.getWriter();
		view=notice.getView();
		createdDate=notice.getCreatedDate();
		updatedDate=notice.getUpdatedDate();
	}
	
	
	
	public Notice toEntity() {
		return Notice.builder()
				.no(no)
				.title(title)
				.content(content)
				.writer(writer)
				.view(view)
				.build();
	}
} 
