package spring.domain.dto;

import lombok.Data;

@Data
public class BoardUpdateDto {

	private String title;
	private String content;
}
