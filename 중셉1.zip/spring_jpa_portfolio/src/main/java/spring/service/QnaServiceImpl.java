package spring.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring.domain.dto.QnaDto;
import spring.domain.dto.QnaUpdateDto;
import spring.domain.entity.QnaEntity;
import spring.domain.repository.QnaRepository;

@Service
public class QnaServiceImpl implements QnaService{
	
	@Autowired
	private QnaRepository qnaRepository;
	// qna 글쓰기 저장
	@Override
	public void qnaWrite(QnaDto dto) {
		qnaRepository.save(dto.toEntity());		
	}
	// qna 리스트 출력
	@Override
	public void getQnaList(int pageNo, Model model) {
		Sort sort=Sort.by(Direction.DESC,"updatedDate");
		Pageable pageable=PageRequest.of(pageNo-1,5, sort);
		Page<QnaEntity> result = qnaRepository.findAll(pageable);
		int pagetotal=result.getTotalPages();
		//출력하기위해 배열로 바꿈
		List<QnaDto> list=
				result.getContent() //BoardDto에 있는 객체를 List타입으로 
				.stream().map(QnaDto::new)//entity -> new BoardDto(entity)
				.collect(Collectors.toList());
		
		model.addAttribute("qnaList", list);
		model.addAttribute("pagetotal", pagetotal);
	}
	// qna 삭제
	@Override
	public void qnaDelete(long no) {
		qnaRepository.deleteById(no);
	}
	// qna 수정
	@Transactional
	@Override
	public void qnaUpdate(long no, QnaUpdateDto dto) {
		qnaRepository.findById(no)
						.map(entity->entity.update(dto))
						.get();
		//boardRepository.findById(id).get().update(dto);//null값이 없다라는 가정
		/*
		Optional<Board> result=boardRepository.findById(id);
		
		if(result.isPresent()) {
			Board entity=result.get();//DB에저장된 원본
			entity=entity.update(dto);
			
			boardRepository.save(entity);
		}
		*/	
	}
	@Override
	public QnaDto getDetails(Long no) {
		QnaEntity qnaEntity = qnaRepository.findById(no).get();
		
		QnaDto qnaDto = QnaDto.builder()
                .no(qnaEntity.getNo())
                .writer(qnaEntity.getContent())
                .title(qnaEntity.getTitle())
                .content(qnaEntity.getContent())
                .view(qnaEntity.getView())
                .createdDate(qnaEntity.getCreatedDate())
                .build();
        return qnaDto;
	}




	


	


}
