package test.service;

import org.springframework.ui.Model;

import test.domain.dto.BoardWriteDto;

public interface BoardService {


	void getBoardList(Model model);

	void save(BoardWriteDto dto);

	void detail(long no, Model model);

}
