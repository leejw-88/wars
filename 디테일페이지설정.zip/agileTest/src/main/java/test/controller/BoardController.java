package test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import test.domain.dto.BoardWriteDto;
import test.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	//게시글 리스트보기
	@GetMapping("/board")
	public String board(Model model) {
		service.getBoardList(model);//계시글리스트를  DB에서 읽어서 확인하도록 처리
		return "/board/list";
	}
	
	@GetMapping("/board/{no}")//요청주소
	public String board(@PathVariable long no,Model model) {
		service.detail(no,model);
		return "/board/detail";//이동할페이지 주소
	}
	
	@GetMapping("/board/write")
	public String wirte() {
		return "/board/write";
	}
	//글쓰기
	@PostMapping("/board/write")
	public String wirte(BoardWriteDto dto) {
		service.save(dto);
		return "redirect:/board";//그냥이동하면 데이터 없음
	}
}
