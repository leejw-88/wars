package test.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@EntityListeners(AuditingEntityListener.class)
@Getter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "agile_test")
@Entity
public class BoardEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long no;//글번호
	@Column(nullable = false)
	private String subject;//제목
	@Column(nullable = false)
	private String content;//내용
	@Column
	private int readCount;//조회수
	@Column(nullable = false)
	private String writer;//작성자
	@CreatedDate
	@Column
	private LocalDateTime createdDate;//작성일
}
