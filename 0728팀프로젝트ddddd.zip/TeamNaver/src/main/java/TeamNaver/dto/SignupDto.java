package TeamNaver.dto;

import java.util.HashSet;
import java.util.Set;

import TeamNaver.entity.User;
import TeamNaver.entity.UserRole;
import lombok.Data;

@Data
public class SignupDto {
	private String userId; //아이디
	private String password; //비밀번호
	private String name; //이름
	private int birthYear; //태어난 년
	private int birthMonth; //태어난 월
	private int birthDay; //태어난 일
	private String sex; //성별
	private String email; //이메일
	private String phone; //핸드폰번호
	private Set<UserRole> roles = new HashSet<>();
	
	public User toEntity() {
		return User.builder()
				.userId(userId)
				.password(password)
				.name(name)
				.birthDay(birthDay)
				.birthMonth(birthMonth)
				.birthYear(birthYear)
				.sex(sex)
				.email(email)
				.phone(phone)
				.build();
	}
}
