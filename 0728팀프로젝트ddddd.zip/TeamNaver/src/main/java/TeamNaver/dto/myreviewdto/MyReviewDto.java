package TeamNaver.dto.myreviewdto;

import lombok.Data;

@Data
public class MyReviewDto {
	private int no;//번호
	private String title;//제목
	private String writer;//작성자
	private String content;//내용
}
