package TeamNaver.controller.myreviewcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import TeamNaver.dto.myreviewdto.MyReviewDto;
import TeamNaver.service.myreviewservice.MyReviewService;

@org.springframework.stereotype.Controller
public class MyReviewController {
	
	@Autowired
	MyReviewService myReviewService;
	
	@GetMapping("/myreview/list") public String list() { 
		return "/myreview/list";
	}
	
	@RequestMapping("/myreview/list")
	public ModelAndView MyReviewList() throws Exception {
		ModelAndView mv = new ModelAndView("/myreview/list");   	//view를 설정해준다.
	    List<MyReviewDto> list = myReviewService.getMyReviewList();	//service를 이용하여 게시판 목록을 데이터베이스에서 조회한다.
	    mv.addObject("list",list);                                	//설정한 뷰로 넘겨줄 데이터를 추가
		
	    return mv;
	}
	
	@GetMapping("/myreview/write")
	public String MyReviewWrite(){
		return "/myreview/write";
	}
}
