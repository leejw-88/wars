package TeamNaver.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import TeamNaver.dto.myreviewdto.MyReviewDto;

@Mapper
public interface MyReviewMapper {
	List<MyReviewDto> getMyReviewList() throws Exception; 
}
