package TeamNaver.service.myreviewservice;

import java.util.List;

import TeamNaver.dto.myreviewdto.MyReviewDto;

public interface MyReviewService {
	
	List<MyReviewDto> getMyReviewList() throws Exception;
}
