package TeamNaver.service.myreviewservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import TeamNaver.dto.myreviewdto.MyReviewDto;
import TeamNaver.mapper.MyReviewMapper;

@org.springframework.stereotype.Service
public class MyReviewServiceImpl implements MyReviewService{

	@Autowired
	private MyReviewMapper myReviewMapper;
	
	@Override
	public List<MyReviewDto> getMyReviewList() throws Exception {
	
		return myReviewMapper.getMyReviewList();
	}

}
