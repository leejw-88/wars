package TeamNaver.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import TeamNaver.dto.SignupDto;
import TeamNaver.entity.User;
import TeamNaver.entity.UserRole;
import TeamNaver.repository.UserRepository;

@Service
public class SignupService {
	@Autowired
	UserRepository userRepository;
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public void signup(SignupDto dto) {
		//암호화
		String encdoe = passwordEncoder.encode(dto.getPassword());
		dto.setPassword(encdoe);
		
		User user = dto.toEntity();
					user.addRole(UserRole.USER); //유저권한 추가
		System.out.println(user);
		userRepository.save(user);			
	}

}
