package TeamNaver.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Bean //비밀번호 암호화(복호화X)
	public PasswordEncoder passwordEncdoer() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//user : 로그인,회원가입(정영훈) 
		//file(주용현님), board(맹준호님), hyo(이철효님), myreview(이제웅님), resin(송진님), reply(윤여운님)
		http.authorizeRequests().antMatchers("/","/user/**","/file/**","/board/**","/hyo/**","/myreview/**","/resin/**","/reply/**").permitAll()
								.anyRequest().authenticated();
		
		http.formLogin().loginPage("/user/login")
			.loginProcessingUrl("/user/signin")
			.usernameParameter("userId")
			.passwordParameter("password");
		
		
		  http.logout().logoutSuccessUrl("/"); //로그아웃하면 인덱스 페이지로
		 		
		http.csrf().disable();
	}
	
	@Override //css, images, js폴더 허용
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/css/**", "/images/**","/js/**");
	}

	
	
}
