package TeamNaver.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class User {
	
	@Id
	@Column(unique = true, nullable = false)
	private String userId; //아이디
	
	@Column(nullable = false)
	private String password; //비밀번호
	
	@Column(nullable = false)
	private String name; //이름
	
	@Column(nullable = false)
	private int birthYear; //태어난 년
	
	@Column(nullable = false)
	private int birthMonth; //태어난 월
	
	@Column(nullable = false)
	private int birthDay; //태어난 일
	
	@Column(nullable = false)
	private String sex; //성별
	
	@Column(nullable = false)
	private String email; //이메일
	
	@Column(nullable = false)
	private String phone; //핸드폰번호
	
	@Enumerated(EnumType.STRING) //DB 저장 String타입
	@ElementCollection(fetch = FetchType.EAGER) //즉시로딩
	@Builder.Default
	private Set<UserRole> roles = new HashSet<>();
	
	//권한 추가 메서드
	public void addRole(UserRole role) {
		roles.add(role);
	}
}
