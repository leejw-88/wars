var timer;
var speed=4000;
$(function(){
	timer=setTimeout(start, speed);
	//마우스가 올라가면 stop함수 실행
	$(".visual-area").hover(stop, function(){
		timer=setTimeout(start, speed);
	});
	
});

function stop(){
	//setTimeout 종료
	clearTimeout(timer);
}

function start(){
	var first=$(".list li").first();
	var last=$(".list li").last();
	
	
	$(".list").animate({marginLeft: -100+'%'},1000,function(){
		/* 첫번째 li를 마지막으로 이동시킨다. */
		last.after(first);
		/* 마진을 0으로 리셋 */
		$(this).css("margin-left",0);
		clearTimeout(timer);
		timer=setTimeout(start, speed);
	});
}