/**
 * 
 */

/*유효성 검사*/
/*$(function(){
	$("input").click(function(){
		$(this).next().css({"display":"block"}).text("asd");
	});
});*/