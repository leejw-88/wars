package spring;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.domain.entity.Member;
import spring.domain.entity.MemberRepository;
import spring.domain.entity.MemberRole;

@SpringBootTest
class SpringSecurityOauth2FApplicationTests {
	@Autowired
	PasswordEncoder	passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	//@Test
	void 관리자아이디생성() {
		
			Member entity=Member.builder()
					.email("admin@test.com")
					.name("관리자")
					.password(passwordEncoder.encode("1234"))
					.phone("0101234567")
					.build();
			entity.addRole(MemberRole.USER);
			entity.addRole(MemberRole.ADMIN);
			memberRepository.save(entity);

	}

}