package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import spring.domain.dto.QnaDto;
import spring.service.QnaService;

@Controller
public class AdminController {
	@Autowired
	QnaService qnaService;
	
	@GetMapping("/admin/list")
	public String list() {
		return "/admin/list";
	}
	
	@GetMapping("/admin/qna/write")
	public String qnaWrite() {
		return "/admin/qna/write";
	}
	@PostMapping("/admin/qna/write")
	public String qnaWrite(QnaDto dto) {
		qnaService.write(dto);
		return "/admin/list";
	}
}
