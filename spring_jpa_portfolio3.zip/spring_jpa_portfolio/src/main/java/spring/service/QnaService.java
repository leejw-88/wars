package spring.service;

import spring.domain.dto.QnaDto;

public interface QnaService {

	void write(QnaDto dto);

}
