package spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.domain.dto.QnaDto;
import spring.domain.entity.QnaEntityRepository;

@Service
public class QnaServiceImpl implements QnaService{


	@Autowired
	private QnaEntityRepository qnaEntityRepository;
	@Override
	public void write(QnaDto dto) {
		qnaEntityRepository.save(dto.toEntity());
		
	}
	
}
