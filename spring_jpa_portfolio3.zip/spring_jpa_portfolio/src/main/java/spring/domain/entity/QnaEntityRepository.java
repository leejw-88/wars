package spring.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaEntityRepository extends JpaRepository<QnaEntity, Long>{

}
