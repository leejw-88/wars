package spring;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.domain.entity.Member;
import spring.domain.entity.MemberRepository;
import spring.domain.entity.MemberRole;

@SpringBootTest
class SpringSecurityOauth2FApplicationTests {
	@Autowired
	PasswordEncoder	passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	@Test
	void contextLoads() {
		IntStream.rangeClosed(1, 3).forEach(i->{
			Member entity=Member.builder()
					.email("test"+i+"@test.com")
					.name("회원"+i)
					.password(passwordEncoder.encode("1234"))
					.build();
			entity.addRole(MemberRole.USER);
			
			if(i==3) {
			entity.addRole(MemberRole.ADMIN);
			}
			
			memberRepository.save(entity);
		});
	}

}