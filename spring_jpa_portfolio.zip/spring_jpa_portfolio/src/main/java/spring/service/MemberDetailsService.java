package spring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import spring.domain.dto.MemberDetails;
import spring.domain.entity.Member;
import spring.domain.entity.MemberRepository;

@Service
public class MemberDetailsService implements UserDetailsService{

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Member> result=memberRepository.findByEmail(username);
		if(result.isEmpty()) {
			throw new UsernameNotFoundException("존재하지 않는 이메일 또는 아이디 입니다.");
		}
		Member entity=result.get();
		MemberDetails memberDetails=new MemberDetails(entity);
		return memberDetails;
	}
	
}
