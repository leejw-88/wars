package spring.domain.dto;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import lombok.Setter;
import spring.domain.entity.Member;

@Setter
@Getter
public class MemberDetails extends User{

	private String name;
	private String phone;
	private boolean isSocial;
	
	public MemberDetails(Member entity) {
		super(
				entity.getEmail(), 		//Id : pk == email
				entity.getPassword(),	//비밀번호
				entity.getRoles().stream()
				.map(role->new SimpleGrantedAuthority(role.getRole()))//"ROLE_USER"
				.collect(Collectors.toSet()));	
		
		name=entity.getName();
		phone=entity.getPhone();
		isSocial=entity.isSocial();
	}
}
