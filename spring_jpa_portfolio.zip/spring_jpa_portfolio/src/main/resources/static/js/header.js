/**
 * 
 */
$(function(){
	//페이지 로딩시 실행되는함수
	pageLoading();
	//마우스 오버시 실행하는 함수
	$(".navi>li").hover(showSubmenu,hideSubmenu);

	
	
});

function pageLoading(){
	$(".submenu").addClass("hide");
}
function showSubmenu(){
	var idx=$(this).index();	
 	$(".submenu").eq(idx).addClass("show");
}
function hideSubmenu(){
 	$(".submenu").removeClass("show");
}
