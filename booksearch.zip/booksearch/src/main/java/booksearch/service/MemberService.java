package booksearch.service;

import org.springframework.ui.Model;

import booksearch.domain.dto.MemberLoginDto;
import booksearch.domain.dto.MemberRequestDto;

public interface MemberService {

	void join(MemberRequestDto dto, Model model);

	String login(MemberLoginDto dto, Model model);

}
