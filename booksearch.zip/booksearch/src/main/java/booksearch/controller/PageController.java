package booksearch.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
	
	/* 로그인 페이지 이동 */
	@GetMapping("/login")
	public String login() {
		return "/login";
	}
	/* 회원가입 페이지 이동 */
	@GetMapping("/signup/signup")
	public String signup() {
		return "/signup/signup";
	}
	@GetMapping("/signup/signup2")
	public String signup2() {
		return "/signup/signup2";
	}
	@GetMapping("/signup/signup3")
	public String signup3() {
		return "/signup/signup3";
	}
	/* 게시판 이동 */
	/* 공지사항 페이지 */
	@GetMapping("/board/notice")
	public String notice() {
		return "/board/notice";
	}
}
