package booksearch.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
	
	/* 로그인 페이지 이동 */
	@GetMapping("/log/login")
	public String login() {
		return "/log/login";
	}
	/* 회원가입 페이지 이동 */
	/* step1 */
	@GetMapping("/signup/signup")
	public String signup() {
		return "/signup/signup";
	}
	/* step2 */
	@GetMapping("/signup/signup2")
	public String signup2() {
		return "/signup/signup2";
	}
	/* step3 */
	@GetMapping("/signup/signup3")
	public String signup3() {
		return "/signup/signup3";
	}
	/* 아이디찾기 페이지이동 */
	@GetMapping("/log/findid")
	public String findid() {
		return "/log/findid";
	}
	/* 비밀번호찾기 페이지이동 */
	@GetMapping("/log/findpass")
	public String findpass() {
		return "/log/findpass";
	}
	
	
	/* 게시판 이동 */
	/* 공지사항 페이지 */
	@GetMapping("/board/notice")
	public String notice() {
		return "/board/notice";
	}
	
	
}
