package booksearch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import booksearch.domain.dto.MemberLoginDto;
import booksearch.domain.dto.MemberRequestDto;
import booksearch.service.MemberService;

@Controller
public class MemberController {
	//멤버로 service
	@Autowired
	private MemberService service;
	
	@PostMapping("/signup/signup2")
	public String join(MemberRequestDto dto, Model model) {
		//System.out.println(dto);
		service.join(dto, model);
		return "/login";
	}
	
	@PostMapping("/login")
	public String login(MemberLoginDto dto, Model model) {
		service.login(dto, model);
		return service.login(dto, model);
	}
}
