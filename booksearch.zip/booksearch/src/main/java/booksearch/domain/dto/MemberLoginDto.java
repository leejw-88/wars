package booksearch.domain.dto;

import booksearch.domain.entitiey.Member;
import lombok.Data;

@Data
public class MemberLoginDto {

	private String userId; //아이디
	private String pass; //비밀번호
	
    public Member toEntitiy() {
    	return Member.builder()
    			.userId(userId)
    			.pass(pass)
    			.build();
    }
}
