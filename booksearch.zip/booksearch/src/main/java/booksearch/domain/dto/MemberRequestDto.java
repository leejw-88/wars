package booksearch.domain.dto;

import booksearch.domain.entitiey.Member;
import lombok.Data;

@Data
public class MemberRequestDto {

	private String name; //이름
	private String userId; //아이디
	private String pass; //비밀번호
	private String email; //이메일
	private String phone; //전화번호
	private String ip; //ip : request에서 얻어오기
	
    public Member toEntitiy() {
    	return Member.builder()
    			.name(name)
    			.userId(userId)
    			.pass(pass)
    			.email(email)
    			.phone(phone)
    			.ip(ip)
    			.build();
    }
}
