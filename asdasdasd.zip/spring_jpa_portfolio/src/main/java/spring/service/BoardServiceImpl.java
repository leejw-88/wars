package spring.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring.domain.dto.BoardDto;
import spring.domain.entity.Board;
import spring.domain.entity.BoardDivision;
import spring.domain.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardRepository boardRepository;

	@Override
	public void saveWrite(BoardDto boardDto) {
		boardRepository.save(boardDto.toEntity());
	}

	// 관리자페이지 글쓰기 저장
	@Override
	public void boardWrite(BoardDto boardDto) {
		boardRepository.save(boardDto.toEntity());
	}
	// board 리스트 불러오기

	@Override
	public void getList(int boardDivision, int pageNo, Model model) {
		BoardDivision div =BoardDivision.values()[boardDivision];
		Sort sort=Sort.by(Direction.DESC,"id");
		Pageable pageable=PageRequest.of(pageNo-1,5, sort);  
		Page<Board> result = boardRepository.findAllByBoardDivision(div.name(),pageable);
		int pagetotal=result.getTotalPages();
		//출력하기위해 배열로 바꿈
		List<BoardDto> list=
				result.getContent() //BoardDto에 있는 객체를 List타입으로 
				.stream().map(BoardDto::new)//entity -> new BoardDto(entity)
				.collect(Collectors.toList());
		
		model.addAttribute("boardDivision", div);
		model.addAttribute("boardList", list);
		model.addAttribute("pagetotal", pagetotal);
		
	}
	


	

}
