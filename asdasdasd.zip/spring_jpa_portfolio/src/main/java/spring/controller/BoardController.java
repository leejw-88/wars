package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import spring.domain.dto.BoardDto;
import spring.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;

	/* //////////// 도서관안내 페이지 ///////////////////////// */
	/* 페이지 이동 */
	@GetMapping("/board/Information")
	public String Information() {
		return "/board/Information/Information";
	}
	
	/* //////////// 도서자료 페이지 ///////////////////////// */
	@GetMapping("/board/material")
	public String material() {
		return "/board/material/material";
	}
	/* //////////// 열린마당 페이지 ///////////////////////// */
	@GetMapping("/board/open")
	public String open() {
		return "/board/open/open";
	}
	// 리스트 불러오기
	@GetMapping("/board/open/{boardDivision}/{pageNo}")
	public String openList(@PathVariable int boardDivision,@PathVariable int pageNo, Model model) {
		boardService.getList(boardDivision,pageNo,model);
		return "/board/tapmenu/listdata";
	}
	// 글쓰기 게시판 이동
	@GetMapping("/post")
	public String openWrite() {
		return "board/tapmenu/write";
	}
	
	// 글쓰기 저장
	@PostMapping("/post")
	public String  openWrite(BoardDto boardDto) {
		boardService.saveWrite(boardDto);
		return "board/open/open";
	}
	
//	@PostMapping("/post")
//	public String  openWrite(BoardDto boardDto) {
//		boardService.saveWrite(boardDto);
//		return "board/open/open";
//	}
	
	
	
	/* //////////// 나의도서관 페이지 ///////////////////////// */
	@GetMapping("/board/mymenu")
	public String mymenu() {
		return "/board/mymenu/mymenu";
	}

	///////////////////////////////////////////
	
}
