package spring.domain.dto;

import lombok.Data;

@Data
public class QnaUpdateDto {

	private String title;
	private String content;
}
