package the.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.ui.LoginPageGeneratingWebFilter;

@EnableWebSecurity
@Configuration
public class SecuritiyConfig extends WebSecurityConfigurerAdapter{
	//인증을 위해서는 반드시 PasswordEncoder를 지정하여야 합니다.
	//BCryptPasswordEncoder bcrypt해시함수를 이용해서 패스워드 암호화하는 클래스
	//1. 복호화가 불가능 : 매번 암호화되는 값이 다릅니다.
	//2. 문자열로 비밀번호가 암호화된 값과 일치하는지만 체크하는 메서드로 확인
	//3. 원본내용확인 불가
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	/*
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
	}
	*/
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers("/","/login",
							"/log/**",
							"/member/**"
							).permitAll()//모든사용자에게 접근허가
				.antMatchers("/test/user").hasRole("USER")//인증권한이 ("user")획득한 사용자
				.antMatchers("/test/manager").hasRole("MANAGER")
				.antMatchers("/test/admin").hasRole("ADMIN")
				.anyRequest()//위에 설정된 url이외의 나머지 모든 url
					.authenticated();//인증된 사용자만 허가
		//.and().객체로 바로이어도됨
		http.formLogin()
				.loginPage("/log/login")
				.loginProcessingUrl("/login")// action="/login"
				.usernameParameter("email")// name="email"
				.passwordParameter("pass")// name="pass"
				
		;//접근허가를 얻지 못한경우 인증처리하기위한 로그인페이지로 이동
		http.logout();
		http.csrf().disable();
		//super.configure(http);
	}


	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring()
			.antMatchers("/resources/**")
			.antMatchers("/css/**")
			.antMatchers("/js/**")
			.antMatchers("/imges/**");
	}
	
	
	
	
}
