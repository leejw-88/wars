package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequestMapping("/test/")
@Controller
public class TestController {
	
	@GetMapping("/user")// /test/user
	public String user() {
		log.info("/test/user 요청처리");
		return "/test/user";
	}
	
	@GetMapping("/manager")// /test/manager
	public String manager() {
		log.info("/test/manager 요청처리");
		return "/test/manager";
	}
	
	@GetMapping("/admin")// /test/admin
	public String admin() {
		log.info("/test/admin 요청처리");
		return "/test/admin";
	}
}
