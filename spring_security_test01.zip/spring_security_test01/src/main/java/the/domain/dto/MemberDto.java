package the.domain.dto;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Data;


@Data
public class MemberDto extends User{
	
	private String email;
	//private String pass;
	private String name;
	
	public MemberDto(String username, String password,String name, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
		email=username;
		this.name=name;
	}
	

}
