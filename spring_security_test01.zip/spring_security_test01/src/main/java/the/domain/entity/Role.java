package the.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Role {
	
	USER("ROLE_USER","회원"),//0
	MANAGER("ROLE_MANAGER","중간관리자"),//1
	ADMIN("ROLE_ADMIN","최종관리자");//2
	
	private final String key;
	private final String title;
	
}
