package the.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepositort extends JpaRepository<MemberTest, String>{

}
