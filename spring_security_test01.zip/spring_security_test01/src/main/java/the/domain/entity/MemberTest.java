package the.domain.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class MemberTest {
	
	@Id
	private String email;

	@Column(nullable = false)
	private String pass;
	
	@Column(nullable = false)
	private String name;
	
	//Entitiy가 아닌 단순한 형태의 객체 집합을 정의하고 관리하는 방법입니다.
	//부모 클래스와 별도로 저장하거나 테이블에서 가져올 수 없다.
	//관계 테이블의 데이터는 무조건 부모와 함계 저장되고 삭제된다.
	//관계하는 테이블의 Entity클래스를 생성하지 않고 사용할때 사용.
	@ElementCollection(fetch = FetchType.LAZY)//FetchType.EAGER:즉시로딩 FetchType.LAZY:지연로딩
	@Enumerated(EnumType.STRING)
	@Builder.Default
	Set<Role> roleSet=new HashSet<>();
	
	public void addRole(Role rloe) {
		roleSet.add(rloe);
	}
}
