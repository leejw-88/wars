package the.service;

import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import the.domain.dto.MemberDto;
import the.domain.entity.MemberRepositort;
import the.domain.entity.MemberTest;

@RequiredArgsConstructor
@Service
public class MemberDetailService implements UserDetailsService{

	private final MemberRepositort memberRepositort;
	
	@Transactional
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<MemberTest> opt=memberRepositort.findById(username);
		if(opt.isEmpty()) {
			throw new UsernameNotFoundException("존재하지 않는 이메일 또는 아이디");
		}
		MemberTest entity=opt.get();
		MemberDto dto=new MemberDto(
							entity.getEmail(), //Id(email)
							entity.getPass(), //비밀번호
							entity.getName(), //이름
							entity.getRoleSet().stream()
								.map(role->new SimpleGrantedAuthority(role.getKey()))// "ROLE_"
								.collect(Collectors.toSet())
							);
		
		return dto;
	}

}
