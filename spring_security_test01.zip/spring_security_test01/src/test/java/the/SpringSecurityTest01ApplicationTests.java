package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import the.domain.entity.MemberRepositort;
import the.domain.entity.MemberTest;
import the.domain.entity.Role;

@SpringBootTest
class SpringSecurityTest01ApplicationTests {
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	MemberRepositort memberRepositort;
	
	
	@Test
	void 임시유저생성() {
		
		
		IntStream.rangeClosed(1, 20).forEach(i->{
			MemberTest mem=MemberTest.builder()
					.email("test"+i+"@test.com")
					.name("test"+i)
					.pass(passwordEncoder.encode("1234"))
					.build();
			//role적용
			mem.addRole(Role.USER);
			if(i>15) {//16~20
				mem.addRole(Role.MANAGER);
			}
			if(i==20) {//20
				mem.addRole(Role.ADMIN);
			}
			
			memberRepositort.save(mem);
			
		});
		
	}

}
