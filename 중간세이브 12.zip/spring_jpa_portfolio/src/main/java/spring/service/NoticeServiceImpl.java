package spring.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import spring.domain.dto.NoticeDto;
import spring.domain.entity.Notice;
import spring.domain.repository.NoticeRepository;

@Service
public class NoticeServiceImpl implements NoticeService{
	
	@Autowired
	private NoticeRepository noticeRepository;
	// 공지사항 리스트 출력
	@Override
	public void getNoticeList(int pageNo, Model model) {
		Sort sort=Sort.by(Direction.DESC,"updatedDate");
		Pageable pageable=PageRequest.of(pageNo-1,5, sort);
		Page<Notice> result = noticeRepository.findAll(pageable);
		int pagetotal=result.getTotalPages();
		//출력하기위해 배열로 바꿈
		List<NoticeDto> list=
				result.getContent() //NoticeDto에 있는 객체를 List타입으로 
				.stream().map(NoticeDto::new)//entity -> new BoardDto(entity)
				.collect(Collectors.toList());
		
		model.addAttribute("noticeList", list);
		model.addAttribute("pagetotal", pagetotal);
	}
	// 공지사항 글쓰기 저장
	@Override
	public void noticeWrite(NoticeDto dto) {
		noticeRepository.save(dto.toEntity());		
	}
	// 공지사항 글 삭제
	@Override
	public void noticeDelete(long no) {
		noticeRepository.deleteById(no);
		
	}

}
