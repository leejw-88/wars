package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import spring.domain.dto.NoticeDto;
import spring.domain.dto.QnaDto;
import spring.domain.dto.RequestedBookDto;
import spring.domain.dto.ReviewDto;
import spring.service.NoticeService;
import spring.service.QnaService;
import spring.service.RequestedBookService;
import spring.service.ReviewService;

@Controller
public class BoardController {
	@Autowired
	private RequestedBookService requestedBookService;
	@Autowired
	private QnaService qnaService;
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private ReviewService reviewService;
	
	/* //////////// 도서관안내 페이지 ///////////////////////// */
	@GetMapping("/board/information")//페이지이동
	public String information() {
		return "/board/information/information";
	}

	@GetMapping("/board/information/greetings")//인사말 페이지 불러오기
	public String infoGreetings() {
		return "/board/information/greetings";
	}
	@GetMapping("/board/information/useinfo")//이용안내 페이지 불러오기
	public String infoUseinfo() {
		return "/board/information/useinfo";
	}
	
	/* //////////// 도서자료 페이지 ///////////////////////// */
	@GetMapping("/board/material")//페이지 이동
	public String material() {
		return "/board/material/material";
	}

	@GetMapping("/board/material/paperback")//단행본 페이지 불러오기
	public String matPaperback() {
		return "/board/material/paperback";
	}
	@GetMapping("/board/material/recommend")//추천도서 페이지 불러오기
	public String matRecommend() {
		return "/board/material/recommend";
	}
	
	/* //////////// 열린마당 페이지 ///////////////////////// */
	@GetMapping("/board/open")//페이지 이동
	public String open() {
		return "/board/open/open";
	}
	/* /////////// 공지사항 페이지 /////////////////////// */
	@GetMapping("/board/open/notice/{pageNo}")//공지사항 페이지 불러오기
	public String openNoticeList(@PathVariable int pageNo,Model model) {
		noticeService.getNoticeList(pageNo, model);
		return "/board/open/notice";
	}
	@ResponseBody
	@DeleteMapping("/board/notice/{no}")//공지사항 페이지 삭제처리
	public void noticeDelete(@PathVariable long no) {
		//System.out.println("delete-no:"+no);
		noticeService.noticeDelete(no);
	}
	// 글쓰기 페이지 이동
	@GetMapping("/board/open/noticeWrite")
	public String noticeWrite() {
		return "/board/open/noticeWrite";
	}
	// 공지사항 글쓰기저장
	@PostMapping("/board/notice/write")
	public String noticeWrite(NoticeDto dto) {
		noticeService.noticeWrite(dto);
		return "redirect:/board/open";
	}
	
	
	
	/* /////////// 묻고답하기(Qna) 페이지 /////////////////////// */
	@GetMapping("/board/open/qnaboard/{pageNo}")//묻고답하기(Qna) 페이지 불러오기
	public String openQnaList(@PathVariable int pageNo,Model model) {
		qnaService.getQnaList(pageNo, model);
		return "/board/open/qnaboard";
	}
	@ResponseBody
	@DeleteMapping("/board/open/{no}")//묻고답하기(Qna) 페이지 삭제처리
	public void qnaDelete(@PathVariable long no) {
		//System.out.println("delete-no:"+no);
		qnaService.qnaDelete(no);
	}
	// 글쓰기 페이지 이동
	@GetMapping("/board/open/qnaWrite")
	public String qnaWrite() {
		return "/board/open/qnaWrite";
	}
	// 묻고답하기 글쓰기 저장
	@PostMapping("/board/qnaboard/write")
	public String qnaWrite(QnaDto dto) {
		qnaService.qnaWrite(dto);
		return "redirect:/board/open";
	}
	
	/* /////////// 도서감상문 페이지 /////////////////////////// */

	@GetMapping("/board/open/bookReview/{pageNo}")//도서감상문 페이지 불러오기
	public String openBookReviewList(@PathVariable int pageNo,Model model) {
		reviewService.getBookReviewList(pageNo, model);
		return "/board/open/bookReview";
	}
	@ResponseBody
	@DeleteMapping("/board/bookReview/{no}")//도서감상문 페이지 삭제처리
	public void bookreviewDelete(@PathVariable long no) {
		//System.out.println("delete-no:"+no);
		reviewService.bookReviewDelete(no);
	}
	// 글쓰기 페이지 이동
	@GetMapping("/board/open/bookReviewWrite")
	public String bookReviewWrite() {
		return "/board/open/bookReviewWrite";
	}
	// 글쓰기 저장
	@PostMapping("/board/bookReview/write")
	public String bookReviewWrite(ReviewDto dto) {
		reviewService.bookReviewWrite(dto);
		return "redirect:/board/open";
	}
	
	/* /////////// 희망도서 페이지 /////////////////////////// */
	@GetMapping("/board/open/requestedbook/{pageNo}")//희망도서 페이지 불러오기
	public String openRequestedBookList(@PathVariable int pageNo,Model model) {
		requestedBookService.getRequestedBookList(pageNo, model);
		return "/board/open/requestedbook";
	}
	@ResponseBody
	@DeleteMapping("/board/requestedbook/{no}")//희망도서 페이지 삭제처리
	public void requestedBookDelete(@PathVariable long no) {
		//System.out.println("delete-no:"+no);
		requestedBookService.requestedBookDelete(no);
	}
	// 글쓰기 페이지 이동
	@GetMapping("/board/open/requestedbookWrite")
	public String requestedbookWrite() {
		return "/board/open/requestedbookWrite";
	}
	// 글쓰기 저장
	@PostMapping("/board/requestedbook/write")
	public String requestedbookWrite(RequestedBookDto dto) {
		requestedBookService.requestedbookWrite(dto);
		return "redirect:/board/open";
	}
	
	
	
	
	/* //////////// 나의도서관 페이지 ///////////////////////// */
	@GetMapping("/board/mymenu")//페이지 이동
	public String mymenu() {
		return "/board/mymenu/mymenu";
	}
	/* ////////////나의 희망도서 페이지 ///////////////////////// */
	@GetMapping("/board/mymenu/myrequestedbook")//나의 희망도서 페이지 불러오기
	public String myRequestedBook() {
		return "/board/mymenu/myrequestedbook";
	}
	/* ////////////나의 도서감상문 페이지 ///////////////////////// */
	@GetMapping("/board/mymenu/mybookreview")//나의 도서감상문 페이지 불러오기
	public String myBookReview() {
		return "/board/mymenu/mybookreview";
	}

	
	
	

}	