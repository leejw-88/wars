package spring;

import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import spring.domain.entity.Member;
import spring.domain.entity.MemberRole;
import spring.domain.entity.QnaEntity;
import spring.domain.repository.MemberRepository;
import spring.domain.repository.QnaRepository;
import spring.domain.repository.RequestedBookRepository;

@SpringBootTest
class SpringSecurityOauth2FApplicationTests {
	@Autowired
	PasswordEncoder	passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	RequestedBookRepository requestedBookRepository;
	@Autowired
	QnaRepository qnaRepository;
	
	//@Test
	void 데이터삽입() {
		
		//Division.values(); //enum요소들을 순서대로 배열
			IntStream.rangeClosed(1, 20).forEach(i->{
				QnaEntity entity=QnaEntity.builder()
						.writer(" 작성자"+i)
						.title(" 제목"+i)
						.content(" 내용"+i)
						.build();
				qnaRepository.save(entity);
			});
		}

	
	
	//@Test
	void 관리자아이디생성() {
		
			Member entity=Member.builder()
					.email("admin@test.com")
					.name("관리자")
					.password(passwordEncoder.encode("1234"))
					.phone("0101234567")
					.build();
			entity.addRole(MemberRole.USER);
			entity.addRole(MemberRole.ADMIN);
			memberRepository.save(entity);
	}

	
	
	
}