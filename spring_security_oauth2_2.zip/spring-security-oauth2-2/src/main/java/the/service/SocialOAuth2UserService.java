package the.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import the.domain.dto.MemberDetails;
import the.domain.entity.Member;
import the.domain.entity.MemberRepository;
import the.domain.entity.MemberRole;

@Service
public class SocialOAuth2UserService extends DefaultOAuth2UserService {
	
	@Autowired
	private PasswordEncoder encoder;
	@Autowired
	MemberRepository repository;
	
	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		OAuth2User oAuth2User = super.loadUser(userRequest);
		//MemberDetails memberDetails = new MemberDetails(oAuth2User);
		
		/*MemberDetails memberDetails = saveSocialMember(oAuth2User);
		Map<String, Object> attributes = oAuth2User.getAttributes();
		
		attributes.keySet().stream().forEach(key->{
			System.out.println(key + ":" + attributes.get(key));
		}); */
		
		return saveSocialMember(oAuth2User); 
	}

	private MemberDetails saveSocialMember(OAuth2User oAuth2User) {
		String email = oAuth2User.getAttribute("email");
		String name = oAuth2User.getAttribute("name");
		
		Member entity = Member.builder()
								.name(name)
								.email(email)
								.nickName(name)
								.isSocial(true)
								.password(encoder.encode("social"+(System.nanoTime()/100000000)))
								.build();
		entity.addRole(MemberRole.USER);
		
		Member result = repository.save(entity);
		
		return new MemberDetails(result);
	}

}
