package the.domain.dto;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.core.user.OAuth2User;

import lombok.Getter;
import the.domain.entity.Member;

@Getter
public class MemberDetails extends User implements OAuth2User{

	private String name;
	private String nickName;
	private boolean isSocial;
	
	private Map<String, Object> attributes;
	@Override
	public Map<String, Object> getAttributes() {	
		return attributes;
	}
	
	public MemberDetails(Member entity) {
		super(
				entity.getEmail(),    //id:pk == email
				entity.getPassword(), //비밀번호
				entity.getRoles().stream()
				.map(role->new SimpleGrantedAuthority(role.getRole())) //"ROLE_USER"
				.collect(Collectors.toSet()));   
		
		name=entity.getName();
		nickName=entity.getNickName();
		isSocial=entity.isSocial();
	}

	public MemberDetails(OAuth2User oAuth2User) {
		super(null, null, null);
		attributes= oAuth2User.getAttributes();
		name = (String)attributes.get("name");
		isSocial=true;
	}

	

}
