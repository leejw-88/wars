package the.domain.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name="member_green")
@Entity
public class Member extends BaseDate {
	@Id
	private String email;
	@Column(nullable = false)
	private String name;
	@Column(unique = true)
	private String nickName;
	@Column(nullable = false)
	private String password;
	
	private boolean isSocial;
	
	
	//Collection<? extend GrantedAuthority> authority;
	@Enumerated(EnumType.STRING)
	@ElementCollection(fetch = FetchType.EAGER)
	@Builder.Default
	private Set<MemberRole> roles=new HashSet<>();
	
	public void addRole(MemberRole role) {
		roles.add(role);
	}
}
