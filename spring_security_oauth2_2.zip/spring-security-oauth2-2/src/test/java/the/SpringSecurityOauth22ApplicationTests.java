package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import the.domain.entity.Member;
import the.domain.entity.MemberRepository;
import the.domain.entity.MemberRole;

@SpringBootTest
class SpringSecurityOauth22ApplicationTests {

	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	MemberRepository memberRepository;
	
	//@Test
	void contextLoads() {
		IntStream.rangeClosed(1, 3).forEach(i->{
			Member entity=Member.builder()
					.email("test"+i+"@test.com")
					.name("회원"+i)
					.password(passwordEncoder.encode("1234"))
					.build();
			entity.addRole(MemberRole.USER);
			
			if(i==3) {
				entity.addRole(MemberRole.ADMIN);
			}
			memberRepository.save(entity);
		});
	}

}
