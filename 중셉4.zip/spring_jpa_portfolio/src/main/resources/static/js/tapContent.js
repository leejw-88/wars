/**
 * 
 */
 $(function(){
	//마우스클릭시 실행하는 함수
	$(".tap-navi>button").click(showContent);
	//페이지 로딩시 실행되는함수
	$(function(){
		pageLoadig();
	});
});
function showContent(){
	$(".content>div").removeClass("show");
	$(".tap-navi>button").css("background-color","#f5f5f5");
	var idx=$(this).index();
	$(".content>div").eq(idx).addClass("show");
	$(".tap-navi>button").eq(idx).css("background-color","#fff");
}
/*
function pageLoadig(){
	$(".tap-navi>button").eq(0).click();
}
*/