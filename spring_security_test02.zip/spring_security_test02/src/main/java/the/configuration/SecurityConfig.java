package the.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()// url설정하는 메서드
				.antMatchers(
						"/",
						"/board/list",
						"/log/**"
						).permitAll()
				.antMatchers("/board/write"
						).hasAnyRole("USER")// "ROLE_USER"인경우  "ROLE_"빼고 "USER"적용
				.antMatchers("/board/list2"
						).hasAnyRole("ADMIN")
				.anyRequest().authenticated();
		http.formLogin()
				.loginPage("/log/login")//url /log/login
				.loginProcessingUrl("/login");//form action=""
		http.csrf().disable();
		
	}

	
	@Override
	public void configure(WebSecurity web) throws Exception {
		//스프링 시큐리티 적용 무시
		web.ignoring()
			.antMatchers("/css/**","/js/**","/images");
	}
	
	
}
