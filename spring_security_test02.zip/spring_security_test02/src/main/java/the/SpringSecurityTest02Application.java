package the;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityTest02Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityTest02Application.class, args);
	}

}
