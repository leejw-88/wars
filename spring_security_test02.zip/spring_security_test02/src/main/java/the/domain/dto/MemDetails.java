package the.domain.dto;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import the.domain.entity.Mem;


@Getter
public class MemDetails extends User{
	//super() 첫번째 문장에만 표현가능합니다.
	private String name;
	public MemDetails(Mem entity) {
		super(entity.getEmail(), entity.getPass(), 
				entity.getRoles().stream()
				//								   ex>"ROLL_USER"
				.map(role->new SimpleGrantedAuthority(role.name()))
				.collect(Collectors.toSet())
			);
		
		name=entity.getName();
		/*
		//Role -> GrantedAuthority
		Set<Role> roles=entity.getRoles();
		Set<SimpleGrantedAuthority> authorities=roles.stream()
				.map(role->new SimpleGrantedAuthority(role.name()))
				.collect(Collectors.toSet());
		*/
	}

}
