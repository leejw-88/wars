package the.domain.entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Getter
public enum Role {
	ROLE_GUEST("게스트"), //0
	ROLE_USER("사용자"), //1
	ROLE_ADMIN("관리자"); //2
	
	private final String title;
	
	
}
