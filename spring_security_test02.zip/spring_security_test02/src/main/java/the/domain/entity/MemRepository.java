package the.domain.entity;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MemRepository extends JpaRepository<Mem, String>{

	Optional<Mem> findByEmail(String username);
	
}
