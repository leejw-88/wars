package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import the.domain.entity.Role;

//접근제한목록 (ACL)
//: 특정리소스나 작업에 대한 둰한을 가진 사용자들만 접근이나 수정들의 작업을 할수 있도록 제어하기 위한 목록

@RequestMapping("/board")
@Controller
public class BoardController {
	
	@GetMapping("/list")
	public String list() {
		return "/board/list";
	}
	@GetMapping("/list2")
	public String list2() {
		return "/board/list2";
	}
	@GetMapping("/write")
	public String write() {
		return "/board/write";
	}
}
