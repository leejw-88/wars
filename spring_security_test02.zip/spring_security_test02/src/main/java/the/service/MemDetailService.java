package the.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import the.domain.dto.MemDetails;
import the.domain.entity.MemRepository;



@Service
public class MemDetailService implements UserDetailsService{

	@Autowired
	private MemRepository memRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		//System.out.println("MemDetailService 실행: "+username);
		//memRepository.findById(username);
		
		return memRepository.findByEmail(username).map(MemDetails::new).orElseThrow();
		//.map(entity->{return new MemDetails(entity);})
		//.map(entity->{new MemDetails(entity);})
				
	}
	
	
}
