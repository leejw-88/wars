package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import the.domain.entity.Mem;
import the.domain.entity.MemRepository;
import the.domain.entity.Role;

@SpringBootTest
class SpringSecurityTest02ApplicationTests {
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	MemRepository memRepository;
	@Test
	void contextLoads() {
		//for(int i=1;i<=3;i++){}  //range(1,3)->for(int i=1;i<3;i++){}
		IntStream.rangeClosed(1, 3).forEach(i->{
			Mem entity=Mem.builder()
					.email("test"+i+"@test.com")
					.pass(passwordEncoder.encode("1234"))
					.name("테스트"+i)
					.build();
		//role
		entity.addRole(Role.ROLE_USER);
	
		if(i==3) {
			entity.addRole(Role.ROLE_ADMIN);
		}
		
		memRepository.save(entity);
		});
	}

}
