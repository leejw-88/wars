package spring.domain.dto.api;

import lombok.Data;

@Data
public class ResultJSONData {
	BoxOfficeResult boxOfficeResult;
}
